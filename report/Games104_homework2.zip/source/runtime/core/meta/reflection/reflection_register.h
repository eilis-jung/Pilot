#pragma once
namespace Pilot
{
    namespace Reflection
    {
        class TypeMetaRegister
        {
        public:
            static void Register();
            static void Unregister();
        };
    } // namespace Reflection
} // namespace Pilot