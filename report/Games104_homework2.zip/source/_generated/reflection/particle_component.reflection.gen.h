#pragma once
#include "runtime\function\framework\component\particle\particle_component.h"

namespace Piccolo{
    class ParticleComponent;
namespace Reflection{
namespace TypeFieldReflectionOparator{
    class TypeParticleComponentOperator{
    public:
        static const char* getClassName(){ return "ParticleComponent";}
        static void* constructorWithJson(const Json& json_context){
            ParticleComponent* ret_instance= new ParticleComponent;
            Serializer::read(json_context, *ret_instance);
            return ret_instance;
        }
        static Json writeByName(void* instance){
            return Serializer::write(*(ParticleComponent*)instance);
        }
        // base class
        static int getParticleComponentBaseClassReflectionInstanceList(ReflectionInstance* &out_list, void* instance){
            int count = 1;
            out_list = new ReflectionInstance[count];
            for (int i=0;i<count;++i){
               out_list[i] = TypeMetaDef(Piccolo::Component,static_cast<ParticleComponent*>(instance));
            }
            return count;
        }
        // fields
        static const char* getFieldName_m_particle_res(){ return "m_particle_res";}
        static const char* getFieldTypeName_m_particle_res(){ return "ParticleComponentRes";}
        static void set_m_particle_res(void* instance, void* field_value){ static_cast<ParticleComponent*>(instance)->m_particle_res = *static_cast<ParticleComponentRes*>(field_value);}
        static void* get_m_particle_res(void* instance){ return static_cast<void*>(&(static_cast<ParticleComponent*>(instance)->m_particle_res));}
        static bool isArray_m_particle_res(){ return false; }
    };
}//namespace TypeFieldReflectionOparator


    void TypeWrapperRegister_ParticleComponent(){
        FieldFunctionTuple* field_function_tuple_m_particle_res=new FieldFunctionTuple(
            &TypeFieldReflectionOparator::TypeParticleComponentOperator::set_m_particle_res,
            &TypeFieldReflectionOparator::TypeParticleComponentOperator::get_m_particle_res,
            &TypeFieldReflectionOparator::TypeParticleComponentOperator::getClassName,
            &TypeFieldReflectionOparator::TypeParticleComponentOperator::getFieldName_m_particle_res,
            &TypeFieldReflectionOparator::TypeParticleComponentOperator::getFieldTypeName_m_particle_res,
            &TypeFieldReflectionOparator::TypeParticleComponentOperator::isArray_m_particle_res);
        REGISTER_FIELD_TO_MAP("ParticleComponent", field_function_tuple_m_particle_res);
        
        
        ClassFunctionTuple* class_function_tuple_ParticleComponent=new ClassFunctionTuple(
            &TypeFieldReflectionOparator::TypeParticleComponentOperator::getParticleComponentBaseClassReflectionInstanceList,
            &TypeFieldReflectionOparator::TypeParticleComponentOperator::constructorWithJson,
            &TypeFieldReflectionOparator::TypeParticleComponentOperator::writeByName);
        REGISTER_BASE_CLASS_TO_MAP("ParticleComponent", class_function_tuple_ParticleComponent);
    }
namespace TypeWrappersRegister{
        void ParticleComponent(){ TypeWrapperRegister_ParticleComponent();}
}//namespace TypeWrappersRegister

}//namespace Reflection
}//namespace Piccolo

