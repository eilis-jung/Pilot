#pragma once
#include "C:/Users/appce/source/repos/Pilot/engine/source/runtime/function/scene/scene_object.h"
namespace Pilot{
class GameObjectMeshDesc;
class SkeletonBindingDesc;
class SkeletonAnimationResultTransform;
class SkeletonAnimationResult;
class GameObjectMaterialDesc;
class GameObjectTransformDesc;
class GameObjectComponentDesc;
namespace Reflection{
namespace TypeFieldReflectionOparator{
   class TypeGameObjectMeshDescOperator{
   public:
       static const char* getClassName(){ return "GameObjectMeshDesc";}
       static void* constructorWithJson(const PJson& json_context){
          GameObjectMeshDesc* ret_instance= new GameObjectMeshDesc;
          PSerializer::read(json_context, *ret_instance);
          return ret_instance;
       }
       static PJson writeByName(void* instance){
          return PSerializer::write(*(GameObjectMeshDesc*)instance);
       }
       // base class
       static int getGameObjectMeshDescBaseClassReflectionInstanceList(ReflectionInstance* &out_list, void* instance){
        int count = 0;
        return count;
       }
       // fields
       static const char* getFieldName_mesh_file(){ return "mesh_file";}
       static const char* getFieldTypeName_mesh_file(){ return "std::string";}
       static void set_mesh_file(void* instance, void* field_value){ static_cast<GameObjectMeshDesc*>(instance)->mesh_file = *static_cast<std::string*>(field_value);}
       static void* get_mesh_file(void* instance){ return static_cast<void*>(&(static_cast<GameObjectMeshDesc*>(instance)->mesh_file));}
       static bool isArray_mesh_file(){ return 0;}
    };
}//namespace TypeFieldReflectionOparator
   void TypeWrapperRegister_GameObjectMeshDesc(){
       filed_function_tuple* f_field_function_tuple_mesh_file=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeGameObjectMeshDescOperator::set_mesh_file,
           &TypeFieldReflectionOparator::TypeGameObjectMeshDescOperator::get_mesh_file,
           &TypeFieldReflectionOparator::TypeGameObjectMeshDescOperator::getClassName,
           &TypeFieldReflectionOparator::TypeGameObjectMeshDescOperator::getFieldName_mesh_file,
           &TypeFieldReflectionOparator::TypeGameObjectMeshDescOperator::getFieldTypeName_mesh_file,
           &TypeFieldReflectionOparator::TypeGameObjectMeshDescOperator::isArray_mesh_file);
       REGISTER_FIELD_TO_MAP("GameObjectMeshDesc", f_field_function_tuple_mesh_file);
       class_function_tuple* f_class_function_tuple_GameObjectMeshDesc=new class_function_tuple(
           &TypeFieldReflectionOparator::TypeGameObjectMeshDescOperator::getGameObjectMeshDescBaseClassReflectionInstanceList,
           &TypeFieldReflectionOparator::TypeGameObjectMeshDescOperator::constructorWithJson,
           &TypeFieldReflectionOparator::TypeGameObjectMeshDescOperator::writeByName);
       REGISTER_BASE_CLASS_TO_MAP("GameObjectMeshDesc", f_class_function_tuple_GameObjectMeshDesc);
   }
namespace TypeFieldReflectionOparator{
   class TypeSkeletonBindingDescOperator{
   public:
       static const char* getClassName(){ return "SkeletonBindingDesc";}
       static void* constructorWithJson(const PJson& json_context){
          SkeletonBindingDesc* ret_instance= new SkeletonBindingDesc;
          PSerializer::read(json_context, *ret_instance);
          return ret_instance;
       }
       static PJson writeByName(void* instance){
          return PSerializer::write(*(SkeletonBindingDesc*)instance);
       }
       // base class
       static int getSkeletonBindingDescBaseClassReflectionInstanceList(ReflectionInstance* &out_list, void* instance){
        int count = 0;
        return count;
       }
       // fields
       static const char* getFieldName_skeleton_binding_file(){ return "skeleton_binding_file";}
       static const char* getFieldTypeName_skeleton_binding_file(){ return "std::string";}
       static void set_skeleton_binding_file(void* instance, void* field_value){ static_cast<SkeletonBindingDesc*>(instance)->skeleton_binding_file = *static_cast<std::string*>(field_value);}
       static void* get_skeleton_binding_file(void* instance){ return static_cast<void*>(&(static_cast<SkeletonBindingDesc*>(instance)->skeleton_binding_file));}
       static bool isArray_skeleton_binding_file(){ return 0;}
    };
}//namespace TypeFieldReflectionOparator
   void TypeWrapperRegister_SkeletonBindingDesc(){
       filed_function_tuple* f_field_function_tuple_skeleton_binding_file=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeSkeletonBindingDescOperator::set_skeleton_binding_file,
           &TypeFieldReflectionOparator::TypeSkeletonBindingDescOperator::get_skeleton_binding_file,
           &TypeFieldReflectionOparator::TypeSkeletonBindingDescOperator::getClassName,
           &TypeFieldReflectionOparator::TypeSkeletonBindingDescOperator::getFieldName_skeleton_binding_file,
           &TypeFieldReflectionOparator::TypeSkeletonBindingDescOperator::getFieldTypeName_skeleton_binding_file,
           &TypeFieldReflectionOparator::TypeSkeletonBindingDescOperator::isArray_skeleton_binding_file);
       REGISTER_FIELD_TO_MAP("SkeletonBindingDesc", f_field_function_tuple_skeleton_binding_file);
       class_function_tuple* f_class_function_tuple_SkeletonBindingDesc=new class_function_tuple(
           &TypeFieldReflectionOparator::TypeSkeletonBindingDescOperator::getSkeletonBindingDescBaseClassReflectionInstanceList,
           &TypeFieldReflectionOparator::TypeSkeletonBindingDescOperator::constructorWithJson,
           &TypeFieldReflectionOparator::TypeSkeletonBindingDescOperator::writeByName);
       REGISTER_BASE_CLASS_TO_MAP("SkeletonBindingDesc", f_class_function_tuple_SkeletonBindingDesc);
   }
namespace TypeFieldReflectionOparator{
   class TypeSkeletonAnimationResultTransformOperator{
   public:
       static const char* getClassName(){ return "SkeletonAnimationResultTransform";}
       static void* constructorWithJson(const PJson& json_context){
          SkeletonAnimationResultTransform* ret_instance= new SkeletonAnimationResultTransform;
          PSerializer::read(json_context, *ret_instance);
          return ret_instance;
       }
       static PJson writeByName(void* instance){
          return PSerializer::write(*(SkeletonAnimationResultTransform*)instance);
       }
       // base class
       static int getSkeletonAnimationResultTransformBaseClassReflectionInstanceList(ReflectionInstance* &out_list, void* instance){
        int count = 0;
        return count;
       }
       // fields
    };
}//namespace TypeFieldReflectionOparator
   void TypeWrapperRegister_SkeletonAnimationResultTransform(){
       class_function_tuple* f_class_function_tuple_SkeletonAnimationResultTransform=new class_function_tuple(
           &TypeFieldReflectionOparator::TypeSkeletonAnimationResultTransformOperator::getSkeletonAnimationResultTransformBaseClassReflectionInstanceList,
           &TypeFieldReflectionOparator::TypeSkeletonAnimationResultTransformOperator::constructorWithJson,
           &TypeFieldReflectionOparator::TypeSkeletonAnimationResultTransformOperator::writeByName);
       REGISTER_BASE_CLASS_TO_MAP("SkeletonAnimationResultTransform", f_class_function_tuple_SkeletonAnimationResultTransform);
   }
namespace TypeFieldReflectionOparator{
   class TypeSkeletonAnimationResultOperator{
   public:
       static const char* getClassName(){ return "SkeletonAnimationResult";}
       static void* constructorWithJson(const PJson& json_context){
          SkeletonAnimationResult* ret_instance= new SkeletonAnimationResult;
          PSerializer::read(json_context, *ret_instance);
          return ret_instance;
       }
       static PJson writeByName(void* instance){
          return PSerializer::write(*(SkeletonAnimationResult*)instance);
       }
       // base class
       static int getSkeletonAnimationResultBaseClassReflectionInstanceList(ReflectionInstance* &out_list, void* instance){
        int count = 0;
        return count;
       }
       // fields
       static const char* getFieldName_transforms(){ return "transforms";}
       static const char* getFieldTypeName_transforms(){ return "std::vector<SkeletonAnimationResultTransform>";}
       static void set_transforms(void* instance, void* field_value){ static_cast<SkeletonAnimationResult*>(instance)->transforms = *static_cast<std::vector<SkeletonAnimationResultTransform>*>(field_value);}
       static void* get_transforms(void* instance){ return static_cast<void*>(&(static_cast<SkeletonAnimationResult*>(instance)->transforms));}
       static bool isArray_transforms(){ return 1;}
    };
}//namespace TypeFieldReflectionOparator
namespace ArrayReflectionOperator{
#ifndef ArraystdSSvectorLSkeletonAnimationResultTransformROperatorMACRO
#define ArraystdSSvectorLSkeletonAnimationResultTransformROperatorMACRO
   class ArraystdSSvectorLSkeletonAnimationResultTransformROperator{
   public:
       static const char* getArrayTypeName(){ return "std::vector<SkeletonAnimationResultTransform>";}
       static const char* getElementTypeName(){ return "SkeletonAnimationResultTransform";}
       static int getSize(void* instance){
           //todo: should check validation
           return static_cast<int>(static_cast<std::vector<SkeletonAnimationResultTransform>*>(instance)->size());
       }
       static void* get(int index,void* instance){
           //todo: should check validation
           return static_cast<void*>(&((*static_cast<std::vector<SkeletonAnimationResultTransform>*>(instance))[index]));
       }
       static void set(int index, void* instance, void* element_value){
           //todo: should check validation
           (*static_cast<std::vector<SkeletonAnimationResultTransform>*>(instance))[index] = *static_cast<SkeletonAnimationResultTransform*>(element_value);
       }
   };
#endif //ArraystdSSvectorLSkeletonAnimationResultTransformROperator
}//namespace ArrayReflectionOperator
   void TypeWrapperRegister_SkeletonAnimationResult(){
       filed_function_tuple* f_field_function_tuple_transforms=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeSkeletonAnimationResultOperator::set_transforms,
           &TypeFieldReflectionOparator::TypeSkeletonAnimationResultOperator::get_transforms,
           &TypeFieldReflectionOparator::TypeSkeletonAnimationResultOperator::getClassName,
           &TypeFieldReflectionOparator::TypeSkeletonAnimationResultOperator::getFieldName_transforms,
           &TypeFieldReflectionOparator::TypeSkeletonAnimationResultOperator::getFieldTypeName_transforms,
           &TypeFieldReflectionOparator::TypeSkeletonAnimationResultOperator::isArray_transforms);
       REGISTER_FIELD_TO_MAP("SkeletonAnimationResult", f_field_function_tuple_transforms);
       array_function_tuple* f_array_tuple_stdSSvectorLSkeletonAnimationResultTransformR = new array_function_tuple(
           &ArrayReflectionOperator::ArraystdSSvectorLSkeletonAnimationResultTransformROperator::set,
           &ArrayReflectionOperator::ArraystdSSvectorLSkeletonAnimationResultTransformROperator::get,
           &ArrayReflectionOperator::ArraystdSSvectorLSkeletonAnimationResultTransformROperator::getSize,
           &ArrayReflectionOperator::ArraystdSSvectorLSkeletonAnimationResultTransformROperator::getArrayTypeName,
           &ArrayReflectionOperator::ArraystdSSvectorLSkeletonAnimationResultTransformROperator::getElementTypeName);
       REGISTER_ARRAY_TO_MAP("std::vector<SkeletonAnimationResultTransform>", f_array_tuple_stdSSvectorLSkeletonAnimationResultTransformR);
       class_function_tuple* f_class_function_tuple_SkeletonAnimationResult=new class_function_tuple(
           &TypeFieldReflectionOparator::TypeSkeletonAnimationResultOperator::getSkeletonAnimationResultBaseClassReflectionInstanceList,
           &TypeFieldReflectionOparator::TypeSkeletonAnimationResultOperator::constructorWithJson,
           &TypeFieldReflectionOparator::TypeSkeletonAnimationResultOperator::writeByName);
       REGISTER_BASE_CLASS_TO_MAP("SkeletonAnimationResult", f_class_function_tuple_SkeletonAnimationResult);
   }
namespace TypeFieldReflectionOparator{
   class TypeGameObjectMaterialDescOperator{
   public:
       static const char* getClassName(){ return "GameObjectMaterialDesc";}
       static void* constructorWithJson(const PJson& json_context){
          GameObjectMaterialDesc* ret_instance= new GameObjectMaterialDesc;
          PSerializer::read(json_context, *ret_instance);
          return ret_instance;
       }
       static PJson writeByName(void* instance){
          return PSerializer::write(*(GameObjectMaterialDesc*)instance);
       }
       // base class
       static int getGameObjectMaterialDescBaseClassReflectionInstanceList(ReflectionInstance* &out_list, void* instance){
        int count = 0;
        return count;
       }
       // fields
       static const char* getFieldName_baseColorTextureFile(){ return "baseColorTextureFile";}
       static const char* getFieldTypeName_baseColorTextureFile(){ return "std::string";}
       static void set_baseColorTextureFile(void* instance, void* field_value){ static_cast<GameObjectMaterialDesc*>(instance)->baseColorTextureFile = *static_cast<std::string*>(field_value);}
       static void* get_baseColorTextureFile(void* instance){ return static_cast<void*>(&(static_cast<GameObjectMaterialDesc*>(instance)->baseColorTextureFile));}
       static bool isArray_baseColorTextureFile(){ return 0;}
       static const char* getFieldName_metallicRoughnessTextureFile(){ return "metallicRoughnessTextureFile";}
       static const char* getFieldTypeName_metallicRoughnessTextureFile(){ return "std::string";}
       static void set_metallicRoughnessTextureFile(void* instance, void* field_value){ static_cast<GameObjectMaterialDesc*>(instance)->metallicRoughnessTextureFile = *static_cast<std::string*>(field_value);}
       static void* get_metallicRoughnessTextureFile(void* instance){ return static_cast<void*>(&(static_cast<GameObjectMaterialDesc*>(instance)->metallicRoughnessTextureFile));}
       static bool isArray_metallicRoughnessTextureFile(){ return 0;}
       static const char* getFieldName_normalTextureFile(){ return "normalTextureFile";}
       static const char* getFieldTypeName_normalTextureFile(){ return "std::string";}
       static void set_normalTextureFile(void* instance, void* field_value){ static_cast<GameObjectMaterialDesc*>(instance)->normalTextureFile = *static_cast<std::string*>(field_value);}
       static void* get_normalTextureFile(void* instance){ return static_cast<void*>(&(static_cast<GameObjectMaterialDesc*>(instance)->normalTextureFile));}
       static bool isArray_normalTextureFile(){ return 0;}
       static const char* getFieldName_occlusionTextureFile(){ return "occlusionTextureFile";}
       static const char* getFieldTypeName_occlusionTextureFile(){ return "std::string";}
       static void set_occlusionTextureFile(void* instance, void* field_value){ static_cast<GameObjectMaterialDesc*>(instance)->occlusionTextureFile = *static_cast<std::string*>(field_value);}
       static void* get_occlusionTextureFile(void* instance){ return static_cast<void*>(&(static_cast<GameObjectMaterialDesc*>(instance)->occlusionTextureFile));}
       static bool isArray_occlusionTextureFile(){ return 0;}
       static const char* getFieldName_emissiveTextureFile(){ return "emissiveTextureFile";}
       static const char* getFieldTypeName_emissiveTextureFile(){ return "std::string";}
       static void set_emissiveTextureFile(void* instance, void* field_value){ static_cast<GameObjectMaterialDesc*>(instance)->emissiveTextureFile = *static_cast<std::string*>(field_value);}
       static void* get_emissiveTextureFile(void* instance){ return static_cast<void*>(&(static_cast<GameObjectMaterialDesc*>(instance)->emissiveTextureFile));}
       static bool isArray_emissiveTextureFile(){ return 0;}
       static const char* getFieldName_with_texture(){ return "with_texture";}
       static const char* getFieldTypeName_with_texture(){ return "bool";}
       static void set_with_texture(void* instance, void* field_value){ static_cast<GameObjectMaterialDesc*>(instance)->with_texture = *static_cast<bool*>(field_value);}
       static void* get_with_texture(void* instance){ return static_cast<void*>(&(static_cast<GameObjectMaterialDesc*>(instance)->with_texture));}
       static bool isArray_with_texture(){ return 0;}
    };
}//namespace TypeFieldReflectionOparator
   void TypeWrapperRegister_GameObjectMaterialDesc(){
       filed_function_tuple* f_field_function_tuple_baseColorTextureFile=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::set_baseColorTextureFile,
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::get_baseColorTextureFile,
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::getClassName,
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::getFieldName_baseColorTextureFile,
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::getFieldTypeName_baseColorTextureFile,
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::isArray_baseColorTextureFile);
       REGISTER_FIELD_TO_MAP("GameObjectMaterialDesc", f_field_function_tuple_baseColorTextureFile);
       filed_function_tuple* f_field_function_tuple_metallicRoughnessTextureFile=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::set_metallicRoughnessTextureFile,
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::get_metallicRoughnessTextureFile,
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::getClassName,
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::getFieldName_metallicRoughnessTextureFile,
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::getFieldTypeName_metallicRoughnessTextureFile,
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::isArray_metallicRoughnessTextureFile);
       REGISTER_FIELD_TO_MAP("GameObjectMaterialDesc", f_field_function_tuple_metallicRoughnessTextureFile);
       filed_function_tuple* f_field_function_tuple_normalTextureFile=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::set_normalTextureFile,
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::get_normalTextureFile,
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::getClassName,
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::getFieldName_normalTextureFile,
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::getFieldTypeName_normalTextureFile,
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::isArray_normalTextureFile);
       REGISTER_FIELD_TO_MAP("GameObjectMaterialDesc", f_field_function_tuple_normalTextureFile);
       filed_function_tuple* f_field_function_tuple_occlusionTextureFile=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::set_occlusionTextureFile,
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::get_occlusionTextureFile,
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::getClassName,
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::getFieldName_occlusionTextureFile,
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::getFieldTypeName_occlusionTextureFile,
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::isArray_occlusionTextureFile);
       REGISTER_FIELD_TO_MAP("GameObjectMaterialDesc", f_field_function_tuple_occlusionTextureFile);
       filed_function_tuple* f_field_function_tuple_emissiveTextureFile=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::set_emissiveTextureFile,
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::get_emissiveTextureFile,
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::getClassName,
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::getFieldName_emissiveTextureFile,
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::getFieldTypeName_emissiveTextureFile,
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::isArray_emissiveTextureFile);
       REGISTER_FIELD_TO_MAP("GameObjectMaterialDesc", f_field_function_tuple_emissiveTextureFile);
       filed_function_tuple* f_field_function_tuple_with_texture=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::set_with_texture,
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::get_with_texture,
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::getClassName,
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::getFieldName_with_texture,
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::getFieldTypeName_with_texture,
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::isArray_with_texture);
       REGISTER_FIELD_TO_MAP("GameObjectMaterialDesc", f_field_function_tuple_with_texture);
       class_function_tuple* f_class_function_tuple_GameObjectMaterialDesc=new class_function_tuple(
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::getGameObjectMaterialDescBaseClassReflectionInstanceList,
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::constructorWithJson,
           &TypeFieldReflectionOparator::TypeGameObjectMaterialDescOperator::writeByName);
       REGISTER_BASE_CLASS_TO_MAP("GameObjectMaterialDesc", f_class_function_tuple_GameObjectMaterialDesc);
   }
namespace TypeFieldReflectionOparator{
   class TypeGameObjectTransformDescOperator{
   public:
       static const char* getClassName(){ return "GameObjectTransformDesc";}
       static void* constructorWithJson(const PJson& json_context){
          GameObjectTransformDesc* ret_instance= new GameObjectTransformDesc;
          PSerializer::read(json_context, *ret_instance);
          return ret_instance;
       }
       static PJson writeByName(void* instance){
          return PSerializer::write(*(GameObjectTransformDesc*)instance);
       }
       // base class
       static int getGameObjectTransformDescBaseClassReflectionInstanceList(ReflectionInstance* &out_list, void* instance){
        int count = 0;
        return count;
       }
       // fields
    };
}//namespace TypeFieldReflectionOparator
   void TypeWrapperRegister_GameObjectTransformDesc(){
       class_function_tuple* f_class_function_tuple_GameObjectTransformDesc=new class_function_tuple(
           &TypeFieldReflectionOparator::TypeGameObjectTransformDescOperator::getGameObjectTransformDescBaseClassReflectionInstanceList,
           &TypeFieldReflectionOparator::TypeGameObjectTransformDescOperator::constructorWithJson,
           &TypeFieldReflectionOparator::TypeGameObjectTransformDescOperator::writeByName);
       REGISTER_BASE_CLASS_TO_MAP("GameObjectTransformDesc", f_class_function_tuple_GameObjectTransformDesc);
   }
namespace TypeFieldReflectionOparator{
   class TypeGameObjectComponentDescOperator{
   public:
       static const char* getClassName(){ return "GameObjectComponentDesc";}
       static void* constructorWithJson(const PJson& json_context){
          GameObjectComponentDesc* ret_instance= new GameObjectComponentDesc;
          PSerializer::read(json_context, *ret_instance);
          return ret_instance;
       }
       static PJson writeByName(void* instance){
          return PSerializer::write(*(GameObjectComponentDesc*)instance);
       }
       // base class
       static int getGameObjectComponentDescBaseClassReflectionInstanceList(ReflectionInstance* &out_list, void* instance){
        int count = 0;
        return count;
       }
       // fields
       static const char* getFieldName_mesh_desc(){ return "mesh_desc";}
       static const char* getFieldTypeName_mesh_desc(){ return "GameObjectMeshDesc";}
       static void set_mesh_desc(void* instance, void* field_value){ static_cast<GameObjectComponentDesc*>(instance)->mesh_desc = *static_cast<GameObjectMeshDesc*>(field_value);}
       static void* get_mesh_desc(void* instance){ return static_cast<void*>(&(static_cast<GameObjectComponentDesc*>(instance)->mesh_desc));}
       static bool isArray_mesh_desc(){ return 0;}
       static const char* getFieldName_material_desc(){ return "material_desc";}
       static const char* getFieldTypeName_material_desc(){ return "GameObjectMaterialDesc";}
       static void set_material_desc(void* instance, void* field_value){ static_cast<GameObjectComponentDesc*>(instance)->material_desc = *static_cast<GameObjectMaterialDesc*>(field_value);}
       static void* get_material_desc(void* instance){ return static_cast<void*>(&(static_cast<GameObjectComponentDesc*>(instance)->material_desc));}
       static bool isArray_material_desc(){ return 0;}
       static const char* getFieldName_transform_desc(){ return "transform_desc";}
       static const char* getFieldTypeName_transform_desc(){ return "GameObjectTransformDesc";}
       static void set_transform_desc(void* instance, void* field_value){ static_cast<GameObjectComponentDesc*>(instance)->transform_desc = *static_cast<GameObjectTransformDesc*>(field_value);}
       static void* get_transform_desc(void* instance){ return static_cast<void*>(&(static_cast<GameObjectComponentDesc*>(instance)->transform_desc));}
       static bool isArray_transform_desc(){ return 0;}
       static const char* getFieldName_with_animation(){ return "with_animation";}
       static const char* getFieldTypeName_with_animation(){ return "bool";}
       static void set_with_animation(void* instance, void* field_value){ static_cast<GameObjectComponentDesc*>(instance)->with_animation = *static_cast<bool*>(field_value);}
       static void* get_with_animation(void* instance){ return static_cast<void*>(&(static_cast<GameObjectComponentDesc*>(instance)->with_animation));}
       static bool isArray_with_animation(){ return 0;}
       static const char* getFieldName_skeleton_binding_desc(){ return "skeleton_binding_desc";}
       static const char* getFieldTypeName_skeleton_binding_desc(){ return "SkeletonBindingDesc";}
       static void set_skeleton_binding_desc(void* instance, void* field_value){ static_cast<GameObjectComponentDesc*>(instance)->skeleton_binding_desc = *static_cast<SkeletonBindingDesc*>(field_value);}
       static void* get_skeleton_binding_desc(void* instance){ return static_cast<void*>(&(static_cast<GameObjectComponentDesc*>(instance)->skeleton_binding_desc));}
       static bool isArray_skeleton_binding_desc(){ return 0;}
       static const char* getFieldName_skeleton_animation_result(){ return "skeleton_animation_result";}
       static const char* getFieldTypeName_skeleton_animation_result(){ return "SkeletonAnimationResult";}
       static void set_skeleton_animation_result(void* instance, void* field_value){ static_cast<GameObjectComponentDesc*>(instance)->skeleton_animation_result = *static_cast<SkeletonAnimationResult*>(field_value);}
       static void* get_skeleton_animation_result(void* instance){ return static_cast<void*>(&(static_cast<GameObjectComponentDesc*>(instance)->skeleton_animation_result));}
       static bool isArray_skeleton_animation_result(){ return 0;}
    };
}//namespace TypeFieldReflectionOparator
   void TypeWrapperRegister_GameObjectComponentDesc(){
       filed_function_tuple* f_field_function_tuple_mesh_desc=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::set_mesh_desc,
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::get_mesh_desc,
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::getClassName,
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::getFieldName_mesh_desc,
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::getFieldTypeName_mesh_desc,
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::isArray_mesh_desc);
       REGISTER_FIELD_TO_MAP("GameObjectComponentDesc", f_field_function_tuple_mesh_desc);
       filed_function_tuple* f_field_function_tuple_material_desc=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::set_material_desc,
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::get_material_desc,
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::getClassName,
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::getFieldName_material_desc,
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::getFieldTypeName_material_desc,
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::isArray_material_desc);
       REGISTER_FIELD_TO_MAP("GameObjectComponentDesc", f_field_function_tuple_material_desc);
       filed_function_tuple* f_field_function_tuple_transform_desc=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::set_transform_desc,
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::get_transform_desc,
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::getClassName,
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::getFieldName_transform_desc,
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::getFieldTypeName_transform_desc,
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::isArray_transform_desc);
       REGISTER_FIELD_TO_MAP("GameObjectComponentDesc", f_field_function_tuple_transform_desc);
       filed_function_tuple* f_field_function_tuple_with_animation=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::set_with_animation,
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::get_with_animation,
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::getClassName,
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::getFieldName_with_animation,
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::getFieldTypeName_with_animation,
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::isArray_with_animation);
       REGISTER_FIELD_TO_MAP("GameObjectComponentDesc", f_field_function_tuple_with_animation);
       filed_function_tuple* f_field_function_tuple_skeleton_binding_desc=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::set_skeleton_binding_desc,
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::get_skeleton_binding_desc,
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::getClassName,
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::getFieldName_skeleton_binding_desc,
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::getFieldTypeName_skeleton_binding_desc,
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::isArray_skeleton_binding_desc);
       REGISTER_FIELD_TO_MAP("GameObjectComponentDesc", f_field_function_tuple_skeleton_binding_desc);
       filed_function_tuple* f_field_function_tuple_skeleton_animation_result=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::set_skeleton_animation_result,
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::get_skeleton_animation_result,
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::getClassName,
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::getFieldName_skeleton_animation_result,
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::getFieldTypeName_skeleton_animation_result,
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::isArray_skeleton_animation_result);
       REGISTER_FIELD_TO_MAP("GameObjectComponentDesc", f_field_function_tuple_skeleton_animation_result);
       class_function_tuple* f_class_function_tuple_GameObjectComponentDesc=new class_function_tuple(
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::getGameObjectComponentDescBaseClassReflectionInstanceList,
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::constructorWithJson,
           &TypeFieldReflectionOparator::TypeGameObjectComponentDescOperator::writeByName);
       REGISTER_BASE_CLASS_TO_MAP("GameObjectComponentDesc", f_class_function_tuple_GameObjectComponentDesc);
   }
namespace TypeWrappersRegister{
    void GameObjectComponentDesc(){ TypeWrapperRegister_GameObjectComponentDesc();}
    void GameObjectMaterialDesc(){ TypeWrapperRegister_GameObjectMaterialDesc();}
    void GameObjectMeshDesc(){ TypeWrapperRegister_GameObjectMeshDesc();}
    void GameObjectTransformDesc(){ TypeWrapperRegister_GameObjectTransformDesc();}
    void SkeletonAnimationResult(){ TypeWrapperRegister_SkeletonAnimationResult();}
    void SkeletonAnimationResultTransform(){ TypeWrapperRegister_SkeletonAnimationResultTransform();}
    void SkeletonBindingDesc(){ TypeWrapperRegister_SkeletonBindingDesc();}
}//namespace TypeWrappersRegister
}//namespace Reflection
}//namespace Pilot
