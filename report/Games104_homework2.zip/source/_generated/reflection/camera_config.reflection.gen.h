#pragma once
#include "C:/Users/appce/source/repos/Pilot/engine/source/runtime/resource/res_type/data/camera_config.h"
namespace Pilot{
class CameraPose;
class CameraConfig;
namespace Reflection{
namespace TypeFieldReflectionOparator{
   class TypeCameraPoseOperator{
   public:
       static const char* getClassName(){ return "CameraPose";}
       static void* constructorWithJson(const PJson& json_context){
          CameraPose* ret_instance= new CameraPose;
          PSerializer::read(json_context, *ret_instance);
          return ret_instance;
       }
       static PJson writeByName(void* instance){
          return PSerializer::write(*(CameraPose*)instance);
       }
       // base class
       static int getCameraPoseBaseClassReflectionInstanceList(ReflectionInstance* &out_list, void* instance){
        int count = 0;
        return count;
       }
       // fields
       static const char* getFieldName_m_position(){ return "m_position";}
       static const char* getFieldTypeName_m_position(){ return "Vector3";}
       static void set_m_position(void* instance, void* field_value){ static_cast<CameraPose*>(instance)->m_position = *static_cast<Vector3*>(field_value);}
       static void* get_m_position(void* instance){ return static_cast<void*>(&(static_cast<CameraPose*>(instance)->m_position));}
       static bool isArray_m_position(){ return 0;}
       static const char* getFieldName_m_target(){ return "m_target";}
       static const char* getFieldTypeName_m_target(){ return "Vector3";}
       static void set_m_target(void* instance, void* field_value){ static_cast<CameraPose*>(instance)->m_target = *static_cast<Vector3*>(field_value);}
       static void* get_m_target(void* instance){ return static_cast<void*>(&(static_cast<CameraPose*>(instance)->m_target));}
       static bool isArray_m_target(){ return 0;}
       static const char* getFieldName_m_up(){ return "m_up";}
       static const char* getFieldTypeName_m_up(){ return "Vector3";}
       static void set_m_up(void* instance, void* field_value){ static_cast<CameraPose*>(instance)->m_up = *static_cast<Vector3*>(field_value);}
       static void* get_m_up(void* instance){ return static_cast<void*>(&(static_cast<CameraPose*>(instance)->m_up));}
       static bool isArray_m_up(){ return 0;}
    };
}//namespace TypeFieldReflectionOparator
   void TypeWrapperRegister_CameraPose(){
       filed_function_tuple* f_field_function_tuple_m_position=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeCameraPoseOperator::set_m_position,
           &TypeFieldReflectionOparator::TypeCameraPoseOperator::get_m_position,
           &TypeFieldReflectionOparator::TypeCameraPoseOperator::getClassName,
           &TypeFieldReflectionOparator::TypeCameraPoseOperator::getFieldName_m_position,
           &TypeFieldReflectionOparator::TypeCameraPoseOperator::getFieldTypeName_m_position,
           &TypeFieldReflectionOparator::TypeCameraPoseOperator::isArray_m_position);
       REGISTER_FIELD_TO_MAP("CameraPose", f_field_function_tuple_m_position);
       filed_function_tuple* f_field_function_tuple_m_target=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeCameraPoseOperator::set_m_target,
           &TypeFieldReflectionOparator::TypeCameraPoseOperator::get_m_target,
           &TypeFieldReflectionOparator::TypeCameraPoseOperator::getClassName,
           &TypeFieldReflectionOparator::TypeCameraPoseOperator::getFieldName_m_target,
           &TypeFieldReflectionOparator::TypeCameraPoseOperator::getFieldTypeName_m_target,
           &TypeFieldReflectionOparator::TypeCameraPoseOperator::isArray_m_target);
       REGISTER_FIELD_TO_MAP("CameraPose", f_field_function_tuple_m_target);
       filed_function_tuple* f_field_function_tuple_m_up=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeCameraPoseOperator::set_m_up,
           &TypeFieldReflectionOparator::TypeCameraPoseOperator::get_m_up,
           &TypeFieldReflectionOparator::TypeCameraPoseOperator::getClassName,
           &TypeFieldReflectionOparator::TypeCameraPoseOperator::getFieldName_m_up,
           &TypeFieldReflectionOparator::TypeCameraPoseOperator::getFieldTypeName_m_up,
           &TypeFieldReflectionOparator::TypeCameraPoseOperator::isArray_m_up);
       REGISTER_FIELD_TO_MAP("CameraPose", f_field_function_tuple_m_up);
       class_function_tuple* f_class_function_tuple_CameraPose=new class_function_tuple(
           &TypeFieldReflectionOparator::TypeCameraPoseOperator::getCameraPoseBaseClassReflectionInstanceList,
           &TypeFieldReflectionOparator::TypeCameraPoseOperator::constructorWithJson,
           &TypeFieldReflectionOparator::TypeCameraPoseOperator::writeByName);
       REGISTER_BASE_CLASS_TO_MAP("CameraPose", f_class_function_tuple_CameraPose);
   }
namespace TypeFieldReflectionOparator{
   class TypeCameraConfigOperator{
   public:
       static const char* getClassName(){ return "CameraConfig";}
       static void* constructorWithJson(const PJson& json_context){
          CameraConfig* ret_instance= new CameraConfig;
          PSerializer::read(json_context, *ret_instance);
          return ret_instance;
       }
       static PJson writeByName(void* instance){
          return PSerializer::write(*(CameraConfig*)instance);
       }
       // base class
       static int getCameraConfigBaseClassReflectionInstanceList(ReflectionInstance* &out_list, void* instance){
        int count = 0;
        return count;
       }
       // fields
       static const char* getFieldName_m_pose(){ return "m_pose";}
       static const char* getFieldTypeName_m_pose(){ return "CameraPose";}
       static void set_m_pose(void* instance, void* field_value){ static_cast<CameraConfig*>(instance)->m_pose = *static_cast<CameraPose*>(field_value);}
       static void* get_m_pose(void* instance){ return static_cast<void*>(&(static_cast<CameraConfig*>(instance)->m_pose));}
       static bool isArray_m_pose(){ return 0;}
       static const char* getFieldName_m_aspect(){ return "m_aspect";}
       static const char* getFieldTypeName_m_aspect(){ return "Vector2";}
       static void set_m_aspect(void* instance, void* field_value){ static_cast<CameraConfig*>(instance)->m_aspect = *static_cast<Vector2*>(field_value);}
       static void* get_m_aspect(void* instance){ return static_cast<void*>(&(static_cast<CameraConfig*>(instance)->m_aspect));}
       static bool isArray_m_aspect(){ return 0;}
       static const char* getFieldName_m_z_far(){ return "m_z_far";}
       static const char* getFieldTypeName_m_z_far(){ return "float";}
       static void set_m_z_far(void* instance, void* field_value){ static_cast<CameraConfig*>(instance)->m_z_far = *static_cast<float*>(field_value);}
       static void* get_m_z_far(void* instance){ return static_cast<void*>(&(static_cast<CameraConfig*>(instance)->m_z_far));}
       static bool isArray_m_z_far(){ return 0;}
       static const char* getFieldName_m_z_near(){ return "m_z_near";}
       static const char* getFieldTypeName_m_z_near(){ return "float";}
       static void set_m_z_near(void* instance, void* field_value){ static_cast<CameraConfig*>(instance)->m_z_near = *static_cast<float*>(field_value);}
       static void* get_m_z_near(void* instance){ return static_cast<void*>(&(static_cast<CameraConfig*>(instance)->m_z_near));}
       static bool isArray_m_z_near(){ return 0;}
    };
}//namespace TypeFieldReflectionOparator
   void TypeWrapperRegister_CameraConfig(){
       filed_function_tuple* f_field_function_tuple_m_pose=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeCameraConfigOperator::set_m_pose,
           &TypeFieldReflectionOparator::TypeCameraConfigOperator::get_m_pose,
           &TypeFieldReflectionOparator::TypeCameraConfigOperator::getClassName,
           &TypeFieldReflectionOparator::TypeCameraConfigOperator::getFieldName_m_pose,
           &TypeFieldReflectionOparator::TypeCameraConfigOperator::getFieldTypeName_m_pose,
           &TypeFieldReflectionOparator::TypeCameraConfigOperator::isArray_m_pose);
       REGISTER_FIELD_TO_MAP("CameraConfig", f_field_function_tuple_m_pose);
       filed_function_tuple* f_field_function_tuple_m_aspect=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeCameraConfigOperator::set_m_aspect,
           &TypeFieldReflectionOparator::TypeCameraConfigOperator::get_m_aspect,
           &TypeFieldReflectionOparator::TypeCameraConfigOperator::getClassName,
           &TypeFieldReflectionOparator::TypeCameraConfigOperator::getFieldName_m_aspect,
           &TypeFieldReflectionOparator::TypeCameraConfigOperator::getFieldTypeName_m_aspect,
           &TypeFieldReflectionOparator::TypeCameraConfigOperator::isArray_m_aspect);
       REGISTER_FIELD_TO_MAP("CameraConfig", f_field_function_tuple_m_aspect);
       filed_function_tuple* f_field_function_tuple_m_z_far=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeCameraConfigOperator::set_m_z_far,
           &TypeFieldReflectionOparator::TypeCameraConfigOperator::get_m_z_far,
           &TypeFieldReflectionOparator::TypeCameraConfigOperator::getClassName,
           &TypeFieldReflectionOparator::TypeCameraConfigOperator::getFieldName_m_z_far,
           &TypeFieldReflectionOparator::TypeCameraConfigOperator::getFieldTypeName_m_z_far,
           &TypeFieldReflectionOparator::TypeCameraConfigOperator::isArray_m_z_far);
       REGISTER_FIELD_TO_MAP("CameraConfig", f_field_function_tuple_m_z_far);
       filed_function_tuple* f_field_function_tuple_m_z_near=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeCameraConfigOperator::set_m_z_near,
           &TypeFieldReflectionOparator::TypeCameraConfigOperator::get_m_z_near,
           &TypeFieldReflectionOparator::TypeCameraConfigOperator::getClassName,
           &TypeFieldReflectionOparator::TypeCameraConfigOperator::getFieldName_m_z_near,
           &TypeFieldReflectionOparator::TypeCameraConfigOperator::getFieldTypeName_m_z_near,
           &TypeFieldReflectionOparator::TypeCameraConfigOperator::isArray_m_z_near);
       REGISTER_FIELD_TO_MAP("CameraConfig", f_field_function_tuple_m_z_near);
       class_function_tuple* f_class_function_tuple_CameraConfig=new class_function_tuple(
           &TypeFieldReflectionOparator::TypeCameraConfigOperator::getCameraConfigBaseClassReflectionInstanceList,
           &TypeFieldReflectionOparator::TypeCameraConfigOperator::constructorWithJson,
           &TypeFieldReflectionOparator::TypeCameraConfigOperator::writeByName);
       REGISTER_BASE_CLASS_TO_MAP("CameraConfig", f_class_function_tuple_CameraConfig);
   }
namespace TypeWrappersRegister{
    void CameraConfig(){ TypeWrapperRegister_CameraConfig();}
    void CameraPose(){ TypeWrapperRegister_CameraPose();}
}//namespace TypeWrappersRegister
}//namespace Reflection
}//namespace Pilot
