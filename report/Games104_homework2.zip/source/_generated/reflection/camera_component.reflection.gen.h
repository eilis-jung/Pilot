#pragma once
#include "C:/Users/appce/source/repos/Pilot/engine/source/runtime/function/framework/component/camera/camera_component.h"
namespace Pilot{
class CameraComponent;
namespace Reflection{
namespace TypeFieldReflectionOparator{
   class TypeCameraComponentOperator{
   public:
       static const char* getClassName(){ return "CameraComponent";}
       static void* constructorWithJson(const PJson& json_context){
          CameraComponent* ret_instance= new CameraComponent;
          PSerializer::read(json_context, *ret_instance);
          return ret_instance;
       }
       static PJson writeByName(void* instance){
          return PSerializer::write(*(CameraComponent*)instance);
       }
       // base class
       static int getCameraComponentBaseClassReflectionInstanceList(ReflectionInstance* &out_list, void* instance){
        int count = 1;
        out_list = new ReflectionInstance[count];
        for (int i=0;i<count;++i){
            out_list[i] = TypeMetaDef(Pilot::Component,static_cast<CameraComponent*>(instance));
        }
        return count;
       }
       // fields
       static const char* getFieldName_m_foward(){ return "m_foward";}
       static const char* getFieldTypeName_m_foward(){ return "Vector3";}
       static void set_m_foward(void* instance, void* field_value){ static_cast<CameraComponent*>(instance)->m_foward = *static_cast<Vector3*>(field_value);}
       static void* get_m_foward(void* instance){ return static_cast<void*>(&(static_cast<CameraComponent*>(instance)->m_foward));}
       static bool isArray_m_foward(){ return 0;}
       static const char* getFieldName_m_up(){ return "m_up";}
       static const char* getFieldTypeName_m_up(){ return "Vector3";}
       static void set_m_up(void* instance, void* field_value){ static_cast<CameraComponent*>(instance)->m_up = *static_cast<Vector3*>(field_value);}
       static void* get_m_up(void* instance){ return static_cast<void*>(&(static_cast<CameraComponent*>(instance)->m_up));}
       static bool isArray_m_up(){ return 0;}
       static const char* getFieldName_m_left(){ return "m_left";}
       static const char* getFieldTypeName_m_left(){ return "Vector3";}
       static void set_m_left(void* instance, void* field_value){ static_cast<CameraComponent*>(instance)->m_left = *static_cast<Vector3*>(field_value);}
       static void* get_m_left(void* instance){ return static_cast<void*>(&(static_cast<CameraComponent*>(instance)->m_left));}
       static bool isArray_m_left(){ return 0;}
    };
}//namespace TypeFieldReflectionOparator
   void TypeWrapperRegister_CameraComponent(){
       filed_function_tuple* f_field_function_tuple_m_foward=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeCameraComponentOperator::set_m_foward,
           &TypeFieldReflectionOparator::TypeCameraComponentOperator::get_m_foward,
           &TypeFieldReflectionOparator::TypeCameraComponentOperator::getClassName,
           &TypeFieldReflectionOparator::TypeCameraComponentOperator::getFieldName_m_foward,
           &TypeFieldReflectionOparator::TypeCameraComponentOperator::getFieldTypeName_m_foward,
           &TypeFieldReflectionOparator::TypeCameraComponentOperator::isArray_m_foward);
       REGISTER_FIELD_TO_MAP("CameraComponent", f_field_function_tuple_m_foward);
       filed_function_tuple* f_field_function_tuple_m_up=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeCameraComponentOperator::set_m_up,
           &TypeFieldReflectionOparator::TypeCameraComponentOperator::get_m_up,
           &TypeFieldReflectionOparator::TypeCameraComponentOperator::getClassName,
           &TypeFieldReflectionOparator::TypeCameraComponentOperator::getFieldName_m_up,
           &TypeFieldReflectionOparator::TypeCameraComponentOperator::getFieldTypeName_m_up,
           &TypeFieldReflectionOparator::TypeCameraComponentOperator::isArray_m_up);
       REGISTER_FIELD_TO_MAP("CameraComponent", f_field_function_tuple_m_up);
       filed_function_tuple* f_field_function_tuple_m_left=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeCameraComponentOperator::set_m_left,
           &TypeFieldReflectionOparator::TypeCameraComponentOperator::get_m_left,
           &TypeFieldReflectionOparator::TypeCameraComponentOperator::getClassName,
           &TypeFieldReflectionOparator::TypeCameraComponentOperator::getFieldName_m_left,
           &TypeFieldReflectionOparator::TypeCameraComponentOperator::getFieldTypeName_m_left,
           &TypeFieldReflectionOparator::TypeCameraComponentOperator::isArray_m_left);
       REGISTER_FIELD_TO_MAP("CameraComponent", f_field_function_tuple_m_left);
       class_function_tuple* f_class_function_tuple_CameraComponent=new class_function_tuple(
           &TypeFieldReflectionOparator::TypeCameraComponentOperator::getCameraComponentBaseClassReflectionInstanceList,
           &TypeFieldReflectionOparator::TypeCameraComponentOperator::constructorWithJson,
           &TypeFieldReflectionOparator::TypeCameraComponentOperator::writeByName);
       REGISTER_BASE_CLASS_TO_MAP("CameraComponent", f_class_function_tuple_CameraComponent);
   }
namespace TypeWrappersRegister{
    void CameraComponent(){ TypeWrapperRegister_CameraComponent();}
}//namespace TypeWrappersRegister
}//namespace Reflection
}//namespace Pilot
