#pragma once
#include "/home/appcell/Pilot/engine/source/runtime/function/framework/component/mesh/mesh_component.h"
namespace Pilot{
class MeshComponent;
namespace Reflection{
namespace TypeFieldReflectionOparator{
   class TypeMeshComponentOperator{
   public:
       static const char* getClassName(){ return "MeshComponent";}
       static void* constructorWithJson(const PJson& json_context){
          MeshComponent* ret_instance= new MeshComponent;
          PSerializer::read(json_context, *ret_instance);
          return ret_instance;
       }
       static PJson writeByName(void* instance){
          return PSerializer::write(*(MeshComponent*)instance);
       }
       // base class
       static int getMeshComponentBaseClassReflectionInstanceList(ReflectionInstance* &out_list, void* instance){
        int count = 1;
        out_list = new ReflectionInstance[count];
        for (int i=0;i<count;++i){
            out_list[i] = TypeMetaDef(Pilot::Component,static_cast<MeshComponent*>(instance));
        }
        return count;
       }
       // fields
       static const char* getFieldName_m_raw_meshes(){ return "m_raw_meshes";}
       static const char* getFieldTypeName_m_raw_meshes(){ return "std::vector<GameObjectComponentDesc>";}
       static void set_m_raw_meshes(void* instance, void* field_value){ static_cast<MeshComponent*>(instance)->m_raw_meshes = *static_cast<std::vector<GameObjectComponentDesc>*>(field_value);}
       static void* get_m_raw_meshes(void* instance){ return static_cast<void*>(&(static_cast<MeshComponent*>(instance)->m_raw_meshes));}
       static bool isArray_m_raw_meshes(){ return 1;}
    };
}//namespace TypeFieldReflectionOparator
namespace ArrayReflectionOperator{
#ifndef ArraystdSSvectorLGameObjectComponentDescROperatorMACRO
#define ArraystdSSvectorLGameObjectComponentDescROperatorMACRO
   class ArraystdSSvectorLGameObjectComponentDescROperator{
   public:
       static const char* getArrayTypeName(){ return "std::vector<GameObjectComponentDesc>";}
       static const char* getElementTypeName(){ return "GameObjectComponentDesc";}
       static int getSize(void* instance){
           //todo: should check validation
           return static_cast<int>(static_cast<std::vector<GameObjectComponentDesc>*>(instance)->size());
       }
       static void* get(int index,void* instance){
           //todo: should check validation
           return static_cast<void*>(&((*static_cast<std::vector<GameObjectComponentDesc>*>(instance))[index]));
       }
       static void set(int index, void* instance, void* element_value){
           //todo: should check validation
           (*static_cast<std::vector<GameObjectComponentDesc>*>(instance))[index] = *static_cast<GameObjectComponentDesc*>(element_value);
       }
   };
#endif //ArraystdSSvectorLGameObjectComponentDescROperator
}//namespace ArrayReflectionOperator
   void TypeWrapperRegister_MeshComponent(){
       filed_function_tuple* f_field_function_tuple_m_raw_meshes=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeMeshComponentOperator::set_m_raw_meshes,
           &TypeFieldReflectionOparator::TypeMeshComponentOperator::get_m_raw_meshes,
           &TypeFieldReflectionOparator::TypeMeshComponentOperator::getClassName,
           &TypeFieldReflectionOparator::TypeMeshComponentOperator::getFieldName_m_raw_meshes,
           &TypeFieldReflectionOparator::TypeMeshComponentOperator::getFieldTypeName_m_raw_meshes,
           &TypeFieldReflectionOparator::TypeMeshComponentOperator::isArray_m_raw_meshes);
       REGISTER_FIELD_TO_MAP("MeshComponent", f_field_function_tuple_m_raw_meshes);
       array_function_tuple* f_array_tuple_stdSSvectorLGameObjectComponentDescR = new array_function_tuple(
           &ArrayReflectionOperator::ArraystdSSvectorLGameObjectComponentDescROperator::set,
           &ArrayReflectionOperator::ArraystdSSvectorLGameObjectComponentDescROperator::get,
           &ArrayReflectionOperator::ArraystdSSvectorLGameObjectComponentDescROperator::getSize,
           &ArrayReflectionOperator::ArraystdSSvectorLGameObjectComponentDescROperator::getArrayTypeName,
           &ArrayReflectionOperator::ArraystdSSvectorLGameObjectComponentDescROperator::getElementTypeName);
       REGISTER_ARRAY_TO_MAP("std::vector<GameObjectComponentDesc>", f_array_tuple_stdSSvectorLGameObjectComponentDescR);
       class_function_tuple* f_class_function_tuple_MeshComponent=new class_function_tuple(
           &TypeFieldReflectionOparator::TypeMeshComponentOperator::getMeshComponentBaseClassReflectionInstanceList,
           &TypeFieldReflectionOparator::TypeMeshComponentOperator::constructorWithJson,
           &TypeFieldReflectionOparator::TypeMeshComponentOperator::writeByName);
       REGISTER_BASE_CLASS_TO_MAP("MeshComponent", f_class_function_tuple_MeshComponent);
   }
namespace TypeWrappersRegister{
    void MeshComponent(){ TypeWrapperRegister_MeshComponent();}
}//namespace TypeWrappersRegister
}//namespace Reflection
}//namespace Pilot
