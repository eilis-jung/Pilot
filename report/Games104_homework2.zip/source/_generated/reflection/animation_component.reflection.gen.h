#pragma once
#include "C:/Users/appce/source/repos/Pilot/engine/source/runtime/function/framework/component/animation/animation_component.h"
namespace Pilot{
class AnimationComponent;
namespace Reflection{
namespace TypeFieldReflectionOparator{
   class TypeAnimationComponentOperator{
   public:
       static const char* getClassName(){ return "AnimationComponent";}
       static void* constructorWithJson(const PJson& json_context){
          AnimationComponent* ret_instance= new AnimationComponent;
          PSerializer::read(json_context, *ret_instance);
          return ret_instance;
       }
       static PJson writeByName(void* instance){
          return PSerializer::write(*(AnimationComponent*)instance);
       }
       // base class
       static int getAnimationComponentBaseClassReflectionInstanceList(ReflectionInstance* &out_list, void* instance){
        int count = 1;
        out_list = new ReflectionInstance[count];
        for (int i=0;i<count;++i){
            out_list[i] = TypeMetaDef(Pilot::Component,static_cast<AnimationComponent*>(instance));
        }
        return count;
       }
       // fields
       static const char* getFieldName_animation_component(){ return "animation_component";}
       static const char* getFieldTypeName_animation_component(){ return "AnimationComponentRes";}
       static void set_animation_component(void* instance, void* field_value){ static_cast<AnimationComponent*>(instance)->animation_component = *static_cast<AnimationComponentRes*>(field_value);}
       static void* get_animation_component(void* instance){ return static_cast<void*>(&(static_cast<AnimationComponent*>(instance)->animation_component));}
       static bool isArray_animation_component(){ return 0;}
    };
}//namespace TypeFieldReflectionOparator
   void TypeWrapperRegister_AnimationComponent(){
       filed_function_tuple* f_field_function_tuple_animation_component=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeAnimationComponentOperator::set_animation_component,
           &TypeFieldReflectionOparator::TypeAnimationComponentOperator::get_animation_component,
           &TypeFieldReflectionOparator::TypeAnimationComponentOperator::getClassName,
           &TypeFieldReflectionOparator::TypeAnimationComponentOperator::getFieldName_animation_component,
           &TypeFieldReflectionOparator::TypeAnimationComponentOperator::getFieldTypeName_animation_component,
           &TypeFieldReflectionOparator::TypeAnimationComponentOperator::isArray_animation_component);
       REGISTER_FIELD_TO_MAP("AnimationComponent", f_field_function_tuple_animation_component);
       class_function_tuple* f_class_function_tuple_AnimationComponent=new class_function_tuple(
           &TypeFieldReflectionOparator::TypeAnimationComponentOperator::getAnimationComponentBaseClassReflectionInstanceList,
           &TypeFieldReflectionOparator::TypeAnimationComponentOperator::constructorWithJson,
           &TypeFieldReflectionOparator::TypeAnimationComponentOperator::writeByName);
       REGISTER_BASE_CLASS_TO_MAP("AnimationComponent", f_class_function_tuple_AnimationComponent);
   }
namespace TypeWrappersRegister{
    void AnimationComponent(){ TypeWrapperRegister_AnimationComponent();}
}//namespace TypeWrappersRegister
}//namespace Reflection
}//namespace Pilot
