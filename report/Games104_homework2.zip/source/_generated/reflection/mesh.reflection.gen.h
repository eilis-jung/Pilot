#pragma once
#include "/home/appcell/Pilot/engine/source/runtime/resource/res_type/components/mesh.h"
namespace Pilot{
class SubMeshRes;
class MeshComponentRes;
namespace Reflection{
namespace TypeFieldReflectionOparator{
   class TypeSubMeshResOperator{
   public:
       static const char* getClassName(){ return "SubMeshRes";}
       static void* constructorWithJson(const PJson& json_context){
          SubMeshRes* ret_instance= new SubMeshRes;
          PSerializer::read(json_context, *ret_instance);
          return ret_instance;
       }
       static PJson writeByName(void* instance){
          return PSerializer::write(*(SubMeshRes*)instance);
       }
       // base class
       static int getSubMeshResBaseClassReflectionInstanceList(ReflectionInstance* &out_list, void* instance){
        int count = 0;
        return count;
       }
       // fields
       static const char* getFieldName_m_obj_file_ref(){ return "m_obj_file_ref";}
       static const char* getFieldTypeName_m_obj_file_ref(){ return "std::string";}
       static void set_m_obj_file_ref(void* instance, void* field_value){ static_cast<SubMeshRes*>(instance)->m_obj_file_ref = *static_cast<std::string*>(field_value);}
       static void* get_m_obj_file_ref(void* instance){ return static_cast<void*>(&(static_cast<SubMeshRes*>(instance)->m_obj_file_ref));}
       static bool isArray_m_obj_file_ref(){ return 0;}
       static const char* getFieldName_m_transform(){ return "m_transform";}
       static const char* getFieldTypeName_m_transform(){ return "Transform";}
       static void set_m_transform(void* instance, void* field_value){ static_cast<SubMeshRes*>(instance)->m_transform = *static_cast<Transform*>(field_value);}
       static void* get_m_transform(void* instance){ return static_cast<void*>(&(static_cast<SubMeshRes*>(instance)->m_transform));}
       static bool isArray_m_transform(){ return 0;}
       static const char* getFieldName_m_material(){ return "m_material";}
       static const char* getFieldTypeName_m_material(){ return "std::string";}
       static void set_m_material(void* instance, void* field_value){ static_cast<SubMeshRes*>(instance)->m_material = *static_cast<std::string*>(field_value);}
       static void* get_m_material(void* instance){ return static_cast<void*>(&(static_cast<SubMeshRes*>(instance)->m_material));}
       static bool isArray_m_material(){ return 0;}
    };
}//namespace TypeFieldReflectionOparator
   void TypeWrapperRegister_SubMeshRes(){
       filed_function_tuple* f_field_function_tuple_m_obj_file_ref=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeSubMeshResOperator::set_m_obj_file_ref,
           &TypeFieldReflectionOparator::TypeSubMeshResOperator::get_m_obj_file_ref,
           &TypeFieldReflectionOparator::TypeSubMeshResOperator::getClassName,
           &TypeFieldReflectionOparator::TypeSubMeshResOperator::getFieldName_m_obj_file_ref,
           &TypeFieldReflectionOparator::TypeSubMeshResOperator::getFieldTypeName_m_obj_file_ref,
           &TypeFieldReflectionOparator::TypeSubMeshResOperator::isArray_m_obj_file_ref);
       REGISTER_FIELD_TO_MAP("SubMeshRes", f_field_function_tuple_m_obj_file_ref);
       filed_function_tuple* f_field_function_tuple_m_transform=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeSubMeshResOperator::set_m_transform,
           &TypeFieldReflectionOparator::TypeSubMeshResOperator::get_m_transform,
           &TypeFieldReflectionOparator::TypeSubMeshResOperator::getClassName,
           &TypeFieldReflectionOparator::TypeSubMeshResOperator::getFieldName_m_transform,
           &TypeFieldReflectionOparator::TypeSubMeshResOperator::getFieldTypeName_m_transform,
           &TypeFieldReflectionOparator::TypeSubMeshResOperator::isArray_m_transform);
       REGISTER_FIELD_TO_MAP("SubMeshRes", f_field_function_tuple_m_transform);
       filed_function_tuple* f_field_function_tuple_m_material=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeSubMeshResOperator::set_m_material,
           &TypeFieldReflectionOparator::TypeSubMeshResOperator::get_m_material,
           &TypeFieldReflectionOparator::TypeSubMeshResOperator::getClassName,
           &TypeFieldReflectionOparator::TypeSubMeshResOperator::getFieldName_m_material,
           &TypeFieldReflectionOparator::TypeSubMeshResOperator::getFieldTypeName_m_material,
           &TypeFieldReflectionOparator::TypeSubMeshResOperator::isArray_m_material);
       REGISTER_FIELD_TO_MAP("SubMeshRes", f_field_function_tuple_m_material);
       class_function_tuple* f_class_function_tuple_SubMeshRes=new class_function_tuple(
           &TypeFieldReflectionOparator::TypeSubMeshResOperator::getSubMeshResBaseClassReflectionInstanceList,
           &TypeFieldReflectionOparator::TypeSubMeshResOperator::constructorWithJson,
           &TypeFieldReflectionOparator::TypeSubMeshResOperator::writeByName);
       REGISTER_BASE_CLASS_TO_MAP("SubMeshRes", f_class_function_tuple_SubMeshRes);
   }
namespace TypeFieldReflectionOparator{
   class TypeMeshComponentResOperator{
   public:
       static const char* getClassName(){ return "MeshComponentRes";}
       static void* constructorWithJson(const PJson& json_context){
          MeshComponentRes* ret_instance= new MeshComponentRes;
          PSerializer::read(json_context, *ret_instance);
          return ret_instance;
       }
       static PJson writeByName(void* instance){
          return PSerializer::write(*(MeshComponentRes*)instance);
       }
       // base class
       static int getMeshComponentResBaseClassReflectionInstanceList(ReflectionInstance* &out_list, void* instance){
        int count = 0;
        return count;
       }
       // fields
       static const char* getFieldName_m_sub_meshes(){ return "m_sub_meshes";}
       static const char* getFieldTypeName_m_sub_meshes(){ return "std::vector<SubMeshRes>";}
       static void set_m_sub_meshes(void* instance, void* field_value){ static_cast<MeshComponentRes*>(instance)->m_sub_meshes = *static_cast<std::vector<SubMeshRes>*>(field_value);}
       static void* get_m_sub_meshes(void* instance){ return static_cast<void*>(&(static_cast<MeshComponentRes*>(instance)->m_sub_meshes));}
       static bool isArray_m_sub_meshes(){ return 1;}
    };
}//namespace TypeFieldReflectionOparator
namespace ArrayReflectionOperator{
#ifndef ArraystdSSvectorLSubMeshResROperatorMACRO
#define ArraystdSSvectorLSubMeshResROperatorMACRO
   class ArraystdSSvectorLSubMeshResROperator{
   public:
       static const char* getArrayTypeName(){ return "std::vector<SubMeshRes>";}
       static const char* getElementTypeName(){ return "SubMeshRes";}
       static int getSize(void* instance){
           //todo: should check validation
           return static_cast<int>(static_cast<std::vector<SubMeshRes>*>(instance)->size());
       }
       static void* get(int index,void* instance){
           //todo: should check validation
           return static_cast<void*>(&((*static_cast<std::vector<SubMeshRes>*>(instance))[index]));
       }
       static void set(int index, void* instance, void* element_value){
           //todo: should check validation
           (*static_cast<std::vector<SubMeshRes>*>(instance))[index] = *static_cast<SubMeshRes*>(element_value);
       }
   };
#endif //ArraystdSSvectorLSubMeshResROperator
}//namespace ArrayReflectionOperator
   void TypeWrapperRegister_MeshComponentRes(){
       filed_function_tuple* f_field_function_tuple_m_sub_meshes=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeMeshComponentResOperator::set_m_sub_meshes,
           &TypeFieldReflectionOparator::TypeMeshComponentResOperator::get_m_sub_meshes,
           &TypeFieldReflectionOparator::TypeMeshComponentResOperator::getClassName,
           &TypeFieldReflectionOparator::TypeMeshComponentResOperator::getFieldName_m_sub_meshes,
           &TypeFieldReflectionOparator::TypeMeshComponentResOperator::getFieldTypeName_m_sub_meshes,
           &TypeFieldReflectionOparator::TypeMeshComponentResOperator::isArray_m_sub_meshes);
       REGISTER_FIELD_TO_MAP("MeshComponentRes", f_field_function_tuple_m_sub_meshes);
       array_function_tuple* f_array_tuple_stdSSvectorLSubMeshResR = new array_function_tuple(
           &ArrayReflectionOperator::ArraystdSSvectorLSubMeshResROperator::set,
           &ArrayReflectionOperator::ArraystdSSvectorLSubMeshResROperator::get,
           &ArrayReflectionOperator::ArraystdSSvectorLSubMeshResROperator::getSize,
           &ArrayReflectionOperator::ArraystdSSvectorLSubMeshResROperator::getArrayTypeName,
           &ArrayReflectionOperator::ArraystdSSvectorLSubMeshResROperator::getElementTypeName);
       REGISTER_ARRAY_TO_MAP("std::vector<SubMeshRes>", f_array_tuple_stdSSvectorLSubMeshResR);
       class_function_tuple* f_class_function_tuple_MeshComponentRes=new class_function_tuple(
           &TypeFieldReflectionOparator::TypeMeshComponentResOperator::getMeshComponentResBaseClassReflectionInstanceList,
           &TypeFieldReflectionOparator::TypeMeshComponentResOperator::constructorWithJson,
           &TypeFieldReflectionOparator::TypeMeshComponentResOperator::writeByName);
       REGISTER_BASE_CLASS_TO_MAP("MeshComponentRes", f_class_function_tuple_MeshComponentRes);
   }
namespace TypeWrappersRegister{
    void MeshComponentRes(){ TypeWrapperRegister_MeshComponentRes();}
    void SubMeshRes(){ TypeWrapperRegister_SubMeshRes();}
}//namespace TypeWrappersRegister
}//namespace Reflection
}//namespace Pilot
