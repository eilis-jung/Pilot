#pragma once
#include "C:/Users/appce/source/repos/Pilot/engine/source/runtime/resource/res_type/common/world.h"
namespace Pilot{
class WorldRes;
namespace Reflection{
namespace TypeFieldReflectionOparator{
   class TypeWorldResOperator{
   public:
       static const char* getClassName(){ return "WorldRes";}
       static void* constructorWithJson(const PJson& json_context){
          WorldRes* ret_instance= new WorldRes;
          PSerializer::read(json_context, *ret_instance);
          return ret_instance;
       }
       static PJson writeByName(void* instance){
          return PSerializer::write(*(WorldRes*)instance);
       }
       // base class
       static int getWorldResBaseClassReflectionInstanceList(ReflectionInstance* &out_list, void* instance){
        int count = 0;
        return count;
       }
       // fields
       static const char* getFieldName_m_name(){ return "m_name";}
       static const char* getFieldTypeName_m_name(){ return "std::string";}
       static void set_m_name(void* instance, void* field_value){ static_cast<WorldRes*>(instance)->m_name = *static_cast<std::string*>(field_value);}
       static void* get_m_name(void* instance){ return static_cast<void*>(&(static_cast<WorldRes*>(instance)->m_name));}
       static bool isArray_m_name(){ return 0;}
       static const char* getFieldName_m_levels(){ return "m_levels";}
       static const char* getFieldTypeName_m_levels(){ return "std::vector<std::string>";}
       static void set_m_levels(void* instance, void* field_value){ static_cast<WorldRes*>(instance)->m_levels = *static_cast<std::vector<std::string>*>(field_value);}
       static void* get_m_levels(void* instance){ return static_cast<void*>(&(static_cast<WorldRes*>(instance)->m_levels));}
       static bool isArray_m_levels(){ return 1;}
    };
}//namespace TypeFieldReflectionOparator
namespace ArrayReflectionOperator{
#ifndef ArraystdSSvectorLstdSSstringROperatorMACRO
#define ArraystdSSvectorLstdSSstringROperatorMACRO
   class ArraystdSSvectorLstdSSstringROperator{
   public:
       static const char* getArrayTypeName(){ return "std::vector<std::string>";}
       static const char* getElementTypeName(){ return "std::string";}
       static int getSize(void* instance){
           //todo: should check validation
           return static_cast<int>(static_cast<std::vector<std::string>*>(instance)->size());
       }
       static void* get(int index,void* instance){
           //todo: should check validation
           return static_cast<void*>(&((*static_cast<std::vector<std::string>*>(instance))[index]));
       }
       static void set(int index, void* instance, void* element_value){
           //todo: should check validation
           (*static_cast<std::vector<std::string>*>(instance))[index] = *static_cast<std::string*>(element_value);
       }
   };
#endif //ArraystdSSvectorLstdSSstringROperator
}//namespace ArrayReflectionOperator
   void TypeWrapperRegister_WorldRes(){
       filed_function_tuple* f_field_function_tuple_m_name=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeWorldResOperator::set_m_name,
           &TypeFieldReflectionOparator::TypeWorldResOperator::get_m_name,
           &TypeFieldReflectionOparator::TypeWorldResOperator::getClassName,
           &TypeFieldReflectionOparator::TypeWorldResOperator::getFieldName_m_name,
           &TypeFieldReflectionOparator::TypeWorldResOperator::getFieldTypeName_m_name,
           &TypeFieldReflectionOparator::TypeWorldResOperator::isArray_m_name);
       REGISTER_FIELD_TO_MAP("WorldRes", f_field_function_tuple_m_name);
       filed_function_tuple* f_field_function_tuple_m_levels=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeWorldResOperator::set_m_levels,
           &TypeFieldReflectionOparator::TypeWorldResOperator::get_m_levels,
           &TypeFieldReflectionOparator::TypeWorldResOperator::getClassName,
           &TypeFieldReflectionOparator::TypeWorldResOperator::getFieldName_m_levels,
           &TypeFieldReflectionOparator::TypeWorldResOperator::getFieldTypeName_m_levels,
           &TypeFieldReflectionOparator::TypeWorldResOperator::isArray_m_levels);
       REGISTER_FIELD_TO_MAP("WorldRes", f_field_function_tuple_m_levels);
       array_function_tuple* f_array_tuple_stdSSvectorLstdSSstringR = new array_function_tuple(
           &ArrayReflectionOperator::ArraystdSSvectorLstdSSstringROperator::set,
           &ArrayReflectionOperator::ArraystdSSvectorLstdSSstringROperator::get,
           &ArrayReflectionOperator::ArraystdSSvectorLstdSSstringROperator::getSize,
           &ArrayReflectionOperator::ArraystdSSvectorLstdSSstringROperator::getArrayTypeName,
           &ArrayReflectionOperator::ArraystdSSvectorLstdSSstringROperator::getElementTypeName);
       REGISTER_ARRAY_TO_MAP("std::vector<std::string>", f_array_tuple_stdSSvectorLstdSSstringR);
       class_function_tuple* f_class_function_tuple_WorldRes=new class_function_tuple(
           &TypeFieldReflectionOparator::TypeWorldResOperator::getWorldResBaseClassReflectionInstanceList,
           &TypeFieldReflectionOparator::TypeWorldResOperator::constructorWithJson,
           &TypeFieldReflectionOparator::TypeWorldResOperator::writeByName);
       REGISTER_BASE_CLASS_TO_MAP("WorldRes", f_class_function_tuple_WorldRes);
   }
namespace TypeWrappersRegister{
    void WorldRes(){ TypeWrapperRegister_WorldRes();}
}//namespace TypeWrappersRegister
}//namespace Reflection
}//namespace Pilot
