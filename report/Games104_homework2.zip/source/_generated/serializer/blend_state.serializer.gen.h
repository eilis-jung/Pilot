#pragma once
#include "C:/Users/appce/source/repos/Pilot/engine/source/runtime/resource/res_type/data/blend_state.h"
namespace Pilot{
    template<>
    PJson PSerializer::write(const BoneBlendWeight& instance);
    template<>
    BoneBlendWeight& PSerializer::read(const PJson& json_context, BoneBlendWeight& instance);
    template<>
    PJson PSerializer::write(const BlendStateWithClipData& instance);
    template<>
    BlendStateWithClipData& PSerializer::read(const PJson& json_context, BlendStateWithClipData& instance);
    template<>
    PJson PSerializer::write(const BlendState& instance);
    template<>
    BlendState& PSerializer::read(const PJson& json_context, BlendState& instance);
}//namespace
