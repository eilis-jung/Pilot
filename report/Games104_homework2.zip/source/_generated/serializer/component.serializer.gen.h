#pragma once
#include "C:/Users/appce/source/repos/Pilot/engine/source/runtime/function/framework/component/component.h"
namespace Pilot{
    template<>
    PJson PSerializer::write(const Component& instance);
    template<>
    Component& PSerializer::read(const PJson& json_context, Component& instance);
}//namespace
