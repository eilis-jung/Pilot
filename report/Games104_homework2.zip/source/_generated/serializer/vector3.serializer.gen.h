#pragma once
#include "/home/appcell/Pilot/engine/source/runtime/core/math/vector3.h"
namespace Pilot{
    template<>
    PJson PSerializer::write(const Vector3& instance);
    template<>
    Vector3& PSerializer::read(const PJson& json_context, Vector3& instance);
}//namespace
