#pragma once
#include "/home/appcell/Pilot/engine/source/runtime/function/framework/component/animation/animation_component.h"
#include "/home/appcell/Pilot/engine/source/_generated/serializer/component.serializer.gen.h"
namespace Pilot{
    template<>
    PJson PSerializer::write(const AnimationComponent& instance);
    template<>
    AnimationComponent& PSerializer::read(const PJson& json_context, AnimationComponent& instance);
}//namespace
