#pragma once
#include "C:/Users/appce/source/repos/Pilot/engine/source/runtime/resource/res_type/components/motor.h"
namespace Pilot{
    template<>
    PJson PSerializer::write(const ControllerConfig& instance);
    template<>
    ControllerConfig& PSerializer::read(const PJson& json_context, ControllerConfig& instance);
    template<>
    PJson PSerializer::write(const PhysicsControllerConfig& instance);
    template<>
    PhysicsControllerConfig& PSerializer::read(const PJson& json_context, PhysicsControllerConfig& instance);
    template<>
    PJson PSerializer::write(const MotorRes& instance);
    template<>
    MotorRes& PSerializer::read(const PJson& json_context, MotorRes& instance);
}//namespace
