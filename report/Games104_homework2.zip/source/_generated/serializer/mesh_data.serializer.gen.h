#pragma once
#include "C:/Users/appce/source/repos/Pilot/engine/source/runtime/resource/res_type/data/mesh_data.h"
namespace Pilot{
    template<>
    PJson PSerializer::write(const Vertex& instance);
    template<>
    Vertex& PSerializer::read(const PJson& json_context, Vertex& instance);
    template<>
    PJson PSerializer::write(const SkeletonBinding& instance);
    template<>
    SkeletonBinding& PSerializer::read(const PJson& json_context, SkeletonBinding& instance);
    template<>
    PJson PSerializer::write(const MeshData& instance);
    template<>
    MeshData& PSerializer::read(const PJson& json_context, MeshData& instance);
}//namespace
