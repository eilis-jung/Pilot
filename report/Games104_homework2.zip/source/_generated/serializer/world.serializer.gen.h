#pragma once
#include "/home/appcell/Pilot/engine/source/runtime/resource/res_type/common/world.h"
namespace Pilot{
    template<>
    PJson PSerializer::write(const WorldRes& instance);
    template<>
    WorldRes& PSerializer::read(const PJson& json_context, WorldRes& instance);
}//namespace
