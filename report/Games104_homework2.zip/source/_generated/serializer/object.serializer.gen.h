#pragma once
#include "C:/Users/appce/source/repos/Pilot/engine/source/runtime/resource/res_type/common/object.h"
namespace Pilot{
    template<>
    PJson PSerializer::write(const ComponentDefinitionRes& instance);
    template<>
    ComponentDefinitionRes& PSerializer::read(const PJson& json_context, ComponentDefinitionRes& instance);
    template<>
    PJson PSerializer::write(const ObjectDefinitionRes& instance);
    template<>
    ObjectDefinitionRes& PSerializer::read(const PJson& json_context, ObjectDefinitionRes& instance);
    template<>
    PJson PSerializer::write(const ObjectInstanceRes& instance);
    template<>
    ObjectInstanceRes& PSerializer::read(const PJson& json_context, ObjectInstanceRes& instance);
}//namespace
