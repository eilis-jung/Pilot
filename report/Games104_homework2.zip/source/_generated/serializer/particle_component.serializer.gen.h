#pragma once
#include "runtime\function\framework\component\particle\particle_component.h"
#include "_generated\serializer\component.serializer.gen.h"

namespace Piccolo{
    template<>
    Json Serializer::write(const ParticleComponent& instance);
    template<>
    ParticleComponent& Serializer::read(const Json& json_context, ParticleComponent& instance);
}//namespace

