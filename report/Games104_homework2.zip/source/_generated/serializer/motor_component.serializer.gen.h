#pragma once
#include "C:/Users/appce/source/repos/Pilot/engine/source/runtime/function/framework/component/motor/motor_component.h"
#include "C:/Users/appce/source/repos/Pilot/engine/source/_generated/serializer/component.serializer.gen.h"
namespace Pilot{
    template<>
    PJson PSerializer::write(const MotorComponent& instance);
    template<>
    MotorComponent& PSerializer::read(const PJson& json_context, MotorComponent& instance);
}//namespace
