#pragma once
#include "C:/Users/appce/source/repos/Pilot/engine/source\runtime/resource/res_type/global/global_rendering.h"
namespace Pilot{
    template<>
    PJson PSerializer::write(const SkyBoxIrradianceMap& instance);
    template<>
    SkyBoxIrradianceMap& PSerializer::read(const PJson& json_context, SkyBoxIrradianceMap& instance);
    template<>
    PJson PSerializer::write(const SkyBoxSpecularMap& instance);
    template<>
    SkyBoxSpecularMap& PSerializer::read(const PJson& json_context, SkyBoxSpecularMap& instance);
    template<>
    PJson PSerializer::write(const DirectionalLight& instance);
    template<>
    DirectionalLight& PSerializer::read(const PJson& json_context, DirectionalLight& instance);
    template<>
    PJson PSerializer::write(const GlobalRenderingRes& instance);
    template<>
    GlobalRenderingRes& PSerializer::read(const PJson& json_context, GlobalRenderingRes& instance);
}//namespace
