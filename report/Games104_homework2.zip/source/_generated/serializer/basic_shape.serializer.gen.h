#pragma once
#include "C:/Users/appce/source/repos/Pilot/engine/source/runtime/resource/res_type/data/basic_shape.h"
namespace Pilot{
    template<>
    PJson PSerializer::write(const Geometry& instance);
    template<>
    Geometry& PSerializer::read(const PJson& json_context, Geometry& instance);
    template<>
    PJson PSerializer::write(const Box& instance);
    template<>
    Box& PSerializer::read(const PJson& json_context, Box& instance);
    template<>
    PJson PSerializer::write(const Sphere& instance);
    template<>
    Sphere& PSerializer::read(const PJson& json_context, Sphere& instance);
    template<>
    PJson PSerializer::write(const Capsule& instance);
    template<>
    Capsule& PSerializer::read(const PJson& json_context, Capsule& instance);
}//namespace
