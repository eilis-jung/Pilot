#pragma once
#include "/home/appcell/Pilot/engine/source/runtime/core/math/axis_aligned.h"
namespace Pilot{
    template<>
    PJson PSerializer::write(const AxisAlignedBox& instance);
    template<>
    AxisAlignedBox& PSerializer::read(const PJson& json_context, AxisAlignedBox& instance);
}//namespace
