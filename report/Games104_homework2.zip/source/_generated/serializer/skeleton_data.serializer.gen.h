#pragma once
#include "C:/Users/appce/source/repos/Pilot/engine/source/runtime/resource/res_type/data/skeleton_data.h"
namespace Pilot{
    template<>
    PJson PSerializer::write(const RawBone& instance);
    template<>
    RawBone& PSerializer::read(const PJson& json_context, RawBone& instance);
    template<>
    PJson PSerializer::write(const SkeletonData& instance);
    template<>
    SkeletonData& PSerializer::read(const PJson& json_context, SkeletonData& instance);
}//namespace
