#pragma once
#include "C:/Users/appce/source/repos/Pilot/engine/source/runtime/resource/res_type/components/mesh.h"
namespace Pilot{
    template<>
    PJson PSerializer::write(const SubMeshRes& instance);
    template<>
    SubMeshRes& PSerializer::read(const PJson& json_context, SubMeshRes& instance);
    template<>
    PJson PSerializer::write(const MeshComponentRes& instance);
    template<>
    MeshComponentRes& PSerializer::read(const PJson& json_context, MeshComponentRes& instance);
}//namespace
