#pragma once
#include "/home/appcell/Pilot/engine/source/runtime/resource/res_type/data/animation_skeleton_node_map.h"
namespace Pilot{
    template<>
    PJson PSerializer::write(const AnimSkelMap& instance);
    template<>
    AnimSkelMap& PSerializer::read(const PJson& json_context, AnimSkelMap& instance);
}//namespace
