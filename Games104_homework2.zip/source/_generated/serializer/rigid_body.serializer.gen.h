#pragma once
#include "/home/appcell/Pilot/engine/source/runtime/resource/res_type/components/rigid_body.h"
namespace Pilot{
    template<>
    PJson PSerializer::write(const RigidBodyShape& instance);
    template<>
    RigidBodyShape& PSerializer::read(const PJson& json_context, RigidBodyShape& instance);
    template<>
    PJson PSerializer::write(const RigidBodyActorRes& instance);
    template<>
    RigidBodyActorRes& PSerializer::read(const PJson& json_context, RigidBodyActorRes& instance);
}//namespace
