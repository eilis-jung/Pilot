#pragma once
#include "/home/appcell/Pilot/engine/source/runtime/core/math/transform.h"
namespace Pilot{
    template<>
    PJson PSerializer::write(const Transform& instance);
    template<>
    Transform& PSerializer::read(const PJson& json_context, Transform& instance);
}//namespace
