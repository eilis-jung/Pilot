#pragma once
#include "/home/appcell/Pilot/engine/source/runtime/function/framework/component/transform/transform_component.h"
#include "/home/appcell/Pilot/engine/source/_generated/serializer/component.serializer.gen.h"
namespace Pilot{
    template<>
    PJson PSerializer::write(const TransformComponent& instance);
    template<>
    TransformComponent& PSerializer::read(const PJson& json_context, TransformComponent& instance);
}//namespace
