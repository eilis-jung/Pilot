#pragma once
#include "/home/appcell/Pilot/engine/source/runtime/function/framework/component/mesh/mesh_component.h"
#include "/home/appcell/Pilot/engine/source/_generated/serializer/component.serializer.gen.h"
namespace Pilot{
    template<>
    PJson PSerializer::write(const MeshComponent& instance);
    template<>
    MeshComponent& PSerializer::read(const PJson& json_context, MeshComponent& instance);
}//namespace
