#pragma once
#include "/home/appcell/Pilot/engine/source/runtime/resource/res_type/data/animation_clip.h"
namespace Pilot{
    template<>
    PJson PSerializer::write(const AnimNodeMap& instance);
    template<>
    AnimNodeMap& PSerializer::read(const PJson& json_context, AnimNodeMap& instance);
    template<>
    PJson PSerializer::write(const AnimationChannel& instance);
    template<>
    AnimationChannel& PSerializer::read(const PJson& json_context, AnimationChannel& instance);
    template<>
    PJson PSerializer::write(const AnimationClip& instance);
    template<>
    AnimationClip& PSerializer::read(const PJson& json_context, AnimationClip& instance);
    template<>
    PJson PSerializer::write(const AnimationAsset& instance);
    template<>
    AnimationAsset& PSerializer::read(const PJson& json_context, AnimationAsset& instance);
}//namespace
