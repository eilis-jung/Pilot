#pragma once
#include "/home/appcell/Pilot/engine/source/runtime/resource/res_type/data/skeleton_mask.h"
namespace Pilot{
    template<>
    PJson PSerializer::write(const BoneBlendMask& instance);
    template<>
    BoneBlendMask& PSerializer::read(const PJson& json_context, BoneBlendMask& instance);
}//namespace
