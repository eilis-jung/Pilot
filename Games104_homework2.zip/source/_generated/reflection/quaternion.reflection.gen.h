#pragma once
#include "/home/appcell/Pilot/engine/source/runtime/core/math/quaternion.h"
namespace Pilot{
class Quaternion;
namespace Reflection{
namespace TypeFieldReflectionOparator{
   class TypeQuaternionOperator{
   public:
       static const char* getClassName(){ return "Quaternion";}
       static void* constructorWithJson(const PJson& json_context){
          Quaternion* ret_instance= new Quaternion;
          PSerializer::read(json_context, *ret_instance);
          return ret_instance;
       }
       static PJson writeByName(void* instance){
          return PSerializer::write(*(Quaternion*)instance);
       }
       // base class
       static int getQuaternionBaseClassReflectionInstanceList(ReflectionInstance* &out_list, void* instance){
        int count = 0;
        return count;
       }
       // fields
       static const char* getFieldName_w(){ return "w";}
       static const char* getFieldTypeName_w(){ return "float";}
       static void set_w(void* instance, void* field_value){ static_cast<Quaternion*>(instance)->w = *static_cast<float*>(field_value);}
       static void* get_w(void* instance){ return static_cast<void*>(&(static_cast<Quaternion*>(instance)->w));}
       static bool isArray_w(){ return 0;}
       static const char* getFieldName_x(){ return "x";}
       static const char* getFieldTypeName_x(){ return "float";}
       static void set_x(void* instance, void* field_value){ static_cast<Quaternion*>(instance)->x = *static_cast<float*>(field_value);}
       static void* get_x(void* instance){ return static_cast<void*>(&(static_cast<Quaternion*>(instance)->x));}
       static bool isArray_x(){ return 0;}
       static const char* getFieldName_y(){ return "y";}
       static const char* getFieldTypeName_y(){ return "float";}
       static void set_y(void* instance, void* field_value){ static_cast<Quaternion*>(instance)->y = *static_cast<float*>(field_value);}
       static void* get_y(void* instance){ return static_cast<void*>(&(static_cast<Quaternion*>(instance)->y));}
       static bool isArray_y(){ return 0;}
       static const char* getFieldName_z(){ return "z";}
       static const char* getFieldTypeName_z(){ return "float";}
       static void set_z(void* instance, void* field_value){ static_cast<Quaternion*>(instance)->z = *static_cast<float*>(field_value);}
       static void* get_z(void* instance){ return static_cast<void*>(&(static_cast<Quaternion*>(instance)->z));}
       static bool isArray_z(){ return 0;}
    };
}//namespace TypeFieldReflectionOparator
   void TypeWrapperRegister_Quaternion(){
       filed_function_tuple* f_field_function_tuple_w=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeQuaternionOperator::set_w,
           &TypeFieldReflectionOparator::TypeQuaternionOperator::get_w,
           &TypeFieldReflectionOparator::TypeQuaternionOperator::getClassName,
           &TypeFieldReflectionOparator::TypeQuaternionOperator::getFieldName_w,
           &TypeFieldReflectionOparator::TypeQuaternionOperator::getFieldTypeName_w,
           &TypeFieldReflectionOparator::TypeQuaternionOperator::isArray_w);
       REGISTER_FIELD_TO_MAP("Quaternion", f_field_function_tuple_w);
       filed_function_tuple* f_field_function_tuple_x=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeQuaternionOperator::set_x,
           &TypeFieldReflectionOparator::TypeQuaternionOperator::get_x,
           &TypeFieldReflectionOparator::TypeQuaternionOperator::getClassName,
           &TypeFieldReflectionOparator::TypeQuaternionOperator::getFieldName_x,
           &TypeFieldReflectionOparator::TypeQuaternionOperator::getFieldTypeName_x,
           &TypeFieldReflectionOparator::TypeQuaternionOperator::isArray_x);
       REGISTER_FIELD_TO_MAP("Quaternion", f_field_function_tuple_x);
       filed_function_tuple* f_field_function_tuple_y=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeQuaternionOperator::set_y,
           &TypeFieldReflectionOparator::TypeQuaternionOperator::get_y,
           &TypeFieldReflectionOparator::TypeQuaternionOperator::getClassName,
           &TypeFieldReflectionOparator::TypeQuaternionOperator::getFieldName_y,
           &TypeFieldReflectionOparator::TypeQuaternionOperator::getFieldTypeName_y,
           &TypeFieldReflectionOparator::TypeQuaternionOperator::isArray_y);
       REGISTER_FIELD_TO_MAP("Quaternion", f_field_function_tuple_y);
       filed_function_tuple* f_field_function_tuple_z=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeQuaternionOperator::set_z,
           &TypeFieldReflectionOparator::TypeQuaternionOperator::get_z,
           &TypeFieldReflectionOparator::TypeQuaternionOperator::getClassName,
           &TypeFieldReflectionOparator::TypeQuaternionOperator::getFieldName_z,
           &TypeFieldReflectionOparator::TypeQuaternionOperator::getFieldTypeName_z,
           &TypeFieldReflectionOparator::TypeQuaternionOperator::isArray_z);
       REGISTER_FIELD_TO_MAP("Quaternion", f_field_function_tuple_z);
       class_function_tuple* f_class_function_tuple_Quaternion=new class_function_tuple(
           &TypeFieldReflectionOparator::TypeQuaternionOperator::getQuaternionBaseClassReflectionInstanceList,
           &TypeFieldReflectionOparator::TypeQuaternionOperator::constructorWithJson,
           &TypeFieldReflectionOparator::TypeQuaternionOperator::writeByName);
       REGISTER_BASE_CLASS_TO_MAP("Quaternion", f_class_function_tuple_Quaternion);
   }
namespace TypeWrappersRegister{
    void Quaternion(){ TypeWrapperRegister_Quaternion();}
}//namespace TypeWrappersRegister
}//namespace Reflection
}//namespace Pilot
