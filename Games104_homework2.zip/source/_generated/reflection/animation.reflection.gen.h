#pragma once
#include "/home/appcell/Pilot/engine/source/runtime/resource/res_type/components/animation.h"
namespace Pilot{
class AnimationResultElement;
class AnimationResult;
class AnimationComponentRes;
class AnimationComponents;
namespace Reflection{
namespace TypeFieldReflectionOparator{
   class TypeAnimationResultElementOperator{
   public:
       static const char* getClassName(){ return "AnimationResultElement";}
       static void* constructorWithJson(const PJson& json_context){
          AnimationResultElement* ret_instance= new AnimationResultElement;
          PSerializer::read(json_context, *ret_instance);
          return ret_instance;
       }
       static PJson writeByName(void* instance){
          return PSerializer::write(*(AnimationResultElement*)instance);
       }
       // base class
       static int getAnimationResultElementBaseClassReflectionInstanceList(ReflectionInstance* &out_list, void* instance){
        int count = 0;
        return count;
       }
       // fields
    };
}//namespace TypeFieldReflectionOparator
   void TypeWrapperRegister_AnimationResultElement(){
       class_function_tuple* f_class_function_tuple_AnimationResultElement=new class_function_tuple(
           &TypeFieldReflectionOparator::TypeAnimationResultElementOperator::getAnimationResultElementBaseClassReflectionInstanceList,
           &TypeFieldReflectionOparator::TypeAnimationResultElementOperator::constructorWithJson,
           &TypeFieldReflectionOparator::TypeAnimationResultElementOperator::writeByName);
       REGISTER_BASE_CLASS_TO_MAP("AnimationResultElement", f_class_function_tuple_AnimationResultElement);
   }
namespace TypeFieldReflectionOparator{
   class TypeAnimationResultOperator{
   public:
       static const char* getClassName(){ return "AnimationResult";}
       static void* constructorWithJson(const PJson& json_context){
          AnimationResult* ret_instance= new AnimationResult;
          PSerializer::read(json_context, *ret_instance);
          return ret_instance;
       }
       static PJson writeByName(void* instance){
          return PSerializer::write(*(AnimationResult*)instance);
       }
       // base class
       static int getAnimationResultBaseClassReflectionInstanceList(ReflectionInstance* &out_list, void* instance){
        int count = 0;
        return count;
       }
       // fields
       static const char* getFieldName_node(){ return "node";}
       static const char* getFieldTypeName_node(){ return "std::vector<AnimationResultElement>";}
       static void set_node(void* instance, void* field_value){ static_cast<AnimationResult*>(instance)->node = *static_cast<std::vector<AnimationResultElement>*>(field_value);}
       static void* get_node(void* instance){ return static_cast<void*>(&(static_cast<AnimationResult*>(instance)->node));}
       static bool isArray_node(){ return 1;}
    };
}//namespace TypeFieldReflectionOparator
namespace ArrayReflectionOperator{
#ifndef ArraystdSSvectorLAnimationResultElementROperatorMACRO
#define ArraystdSSvectorLAnimationResultElementROperatorMACRO
   class ArraystdSSvectorLAnimationResultElementROperator{
   public:
       static const char* getArrayTypeName(){ return "std::vector<AnimationResultElement>";}
       static const char* getElementTypeName(){ return "AnimationResultElement";}
       static int getSize(void* instance){
           //todo: should check validation
           return static_cast<int>(static_cast<std::vector<AnimationResultElement>*>(instance)->size());
       }
       static void* get(int index,void* instance){
           //todo: should check validation
           return static_cast<void*>(&((*static_cast<std::vector<AnimationResultElement>*>(instance))[index]));
       }
       static void set(int index, void* instance, void* element_value){
           //todo: should check validation
           (*static_cast<std::vector<AnimationResultElement>*>(instance))[index] = *static_cast<AnimationResultElement*>(element_value);
       }
   };
#endif //ArraystdSSvectorLAnimationResultElementROperator
}//namespace ArrayReflectionOperator
   void TypeWrapperRegister_AnimationResult(){
       filed_function_tuple* f_field_function_tuple_node=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeAnimationResultOperator::set_node,
           &TypeFieldReflectionOparator::TypeAnimationResultOperator::get_node,
           &TypeFieldReflectionOparator::TypeAnimationResultOperator::getClassName,
           &TypeFieldReflectionOparator::TypeAnimationResultOperator::getFieldName_node,
           &TypeFieldReflectionOparator::TypeAnimationResultOperator::getFieldTypeName_node,
           &TypeFieldReflectionOparator::TypeAnimationResultOperator::isArray_node);
       REGISTER_FIELD_TO_MAP("AnimationResult", f_field_function_tuple_node);
       array_function_tuple* f_array_tuple_stdSSvectorLAnimationResultElementR = new array_function_tuple(
           &ArrayReflectionOperator::ArraystdSSvectorLAnimationResultElementROperator::set,
           &ArrayReflectionOperator::ArraystdSSvectorLAnimationResultElementROperator::get,
           &ArrayReflectionOperator::ArraystdSSvectorLAnimationResultElementROperator::getSize,
           &ArrayReflectionOperator::ArraystdSSvectorLAnimationResultElementROperator::getArrayTypeName,
           &ArrayReflectionOperator::ArraystdSSvectorLAnimationResultElementROperator::getElementTypeName);
       REGISTER_ARRAY_TO_MAP("std::vector<AnimationResultElement>", f_array_tuple_stdSSvectorLAnimationResultElementR);
       class_function_tuple* f_class_function_tuple_AnimationResult=new class_function_tuple(
           &TypeFieldReflectionOparator::TypeAnimationResultOperator::getAnimationResultBaseClassReflectionInstanceList,
           &TypeFieldReflectionOparator::TypeAnimationResultOperator::constructorWithJson,
           &TypeFieldReflectionOparator::TypeAnimationResultOperator::writeByName);
       REGISTER_BASE_CLASS_TO_MAP("AnimationResult", f_class_function_tuple_AnimationResult);
   }
namespace TypeFieldReflectionOparator{
   class TypeAnimationComponentResOperator{
   public:
       static const char* getClassName(){ return "AnimationComponentRes";}
       static void* constructorWithJson(const PJson& json_context){
          AnimationComponentRes* ret_instance= new AnimationComponentRes;
          PSerializer::read(json_context, *ret_instance);
          return ret_instance;
       }
       static PJson writeByName(void* instance){
          return PSerializer::write(*(AnimationComponentRes*)instance);
       }
       // base class
       static int getAnimationComponentResBaseClassReflectionInstanceList(ReflectionInstance* &out_list, void* instance){
        int count = 0;
        return count;
       }
       // fields
       static const char* getFieldName_skeleton_file_path(){ return "skeleton_file_path";}
       static const char* getFieldTypeName_skeleton_file_path(){ return "std::string";}
       static void set_skeleton_file_path(void* instance, void* field_value){ static_cast<AnimationComponentRes*>(instance)->skeleton_file_path = *static_cast<std::string*>(field_value);}
       static void* get_skeleton_file_path(void* instance){ return static_cast<void*>(&(static_cast<AnimationComponentRes*>(instance)->skeleton_file_path));}
       static bool isArray_skeleton_file_path(){ return 0;}
       static const char* getFieldName_blend_state(){ return "blend_state";}
       static const char* getFieldTypeName_blend_state(){ return "BlendState";}
       static void set_blend_state(void* instance, void* field_value){ static_cast<AnimationComponentRes*>(instance)->blend_state = *static_cast<BlendState*>(field_value);}
       static void* get_blend_state(void* instance){ return static_cast<void*>(&(static_cast<AnimationComponentRes*>(instance)->blend_state));}
       static bool isArray_blend_state(){ return 0;}
       static const char* getFieldName_frame_position(){ return "frame_position";}
       static const char* getFieldTypeName_frame_position(){ return "float";}
       static void set_frame_position(void* instance, void* field_value){ static_cast<AnimationComponentRes*>(instance)->frame_position = *static_cast<float*>(field_value);}
       static void* get_frame_position(void* instance){ return static_cast<void*>(&(static_cast<AnimationComponentRes*>(instance)->frame_position));}
       static bool isArray_frame_position(){ return 0;}
       static const char* getFieldName_animation_result(){ return "animation_result";}
       static const char* getFieldTypeName_animation_result(){ return "AnimationResult";}
       static void set_animation_result(void* instance, void* field_value){ static_cast<AnimationComponentRes*>(instance)->animation_result = *static_cast<AnimationResult*>(field_value);}
       static void* get_animation_result(void* instance){ return static_cast<void*>(&(static_cast<AnimationComponentRes*>(instance)->animation_result));}
       static bool isArray_animation_result(){ return 0;}
    };
}//namespace TypeFieldReflectionOparator
   void TypeWrapperRegister_AnimationComponentRes(){
       filed_function_tuple* f_field_function_tuple_skeleton_file_path=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeAnimationComponentResOperator::set_skeleton_file_path,
           &TypeFieldReflectionOparator::TypeAnimationComponentResOperator::get_skeleton_file_path,
           &TypeFieldReflectionOparator::TypeAnimationComponentResOperator::getClassName,
           &TypeFieldReflectionOparator::TypeAnimationComponentResOperator::getFieldName_skeleton_file_path,
           &TypeFieldReflectionOparator::TypeAnimationComponentResOperator::getFieldTypeName_skeleton_file_path,
           &TypeFieldReflectionOparator::TypeAnimationComponentResOperator::isArray_skeleton_file_path);
       REGISTER_FIELD_TO_MAP("AnimationComponentRes", f_field_function_tuple_skeleton_file_path);
       filed_function_tuple* f_field_function_tuple_blend_state=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeAnimationComponentResOperator::set_blend_state,
           &TypeFieldReflectionOparator::TypeAnimationComponentResOperator::get_blend_state,
           &TypeFieldReflectionOparator::TypeAnimationComponentResOperator::getClassName,
           &TypeFieldReflectionOparator::TypeAnimationComponentResOperator::getFieldName_blend_state,
           &TypeFieldReflectionOparator::TypeAnimationComponentResOperator::getFieldTypeName_blend_state,
           &TypeFieldReflectionOparator::TypeAnimationComponentResOperator::isArray_blend_state);
       REGISTER_FIELD_TO_MAP("AnimationComponentRes", f_field_function_tuple_blend_state);
       filed_function_tuple* f_field_function_tuple_frame_position=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeAnimationComponentResOperator::set_frame_position,
           &TypeFieldReflectionOparator::TypeAnimationComponentResOperator::get_frame_position,
           &TypeFieldReflectionOparator::TypeAnimationComponentResOperator::getClassName,
           &TypeFieldReflectionOparator::TypeAnimationComponentResOperator::getFieldName_frame_position,
           &TypeFieldReflectionOparator::TypeAnimationComponentResOperator::getFieldTypeName_frame_position,
           &TypeFieldReflectionOparator::TypeAnimationComponentResOperator::isArray_frame_position);
       REGISTER_FIELD_TO_MAP("AnimationComponentRes", f_field_function_tuple_frame_position);
       filed_function_tuple* f_field_function_tuple_animation_result=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeAnimationComponentResOperator::set_animation_result,
           &TypeFieldReflectionOparator::TypeAnimationComponentResOperator::get_animation_result,
           &TypeFieldReflectionOparator::TypeAnimationComponentResOperator::getClassName,
           &TypeFieldReflectionOparator::TypeAnimationComponentResOperator::getFieldName_animation_result,
           &TypeFieldReflectionOparator::TypeAnimationComponentResOperator::getFieldTypeName_animation_result,
           &TypeFieldReflectionOparator::TypeAnimationComponentResOperator::isArray_animation_result);
       REGISTER_FIELD_TO_MAP("AnimationComponentRes", f_field_function_tuple_animation_result);
       class_function_tuple* f_class_function_tuple_AnimationComponentRes=new class_function_tuple(
           &TypeFieldReflectionOparator::TypeAnimationComponentResOperator::getAnimationComponentResBaseClassReflectionInstanceList,
           &TypeFieldReflectionOparator::TypeAnimationComponentResOperator::constructorWithJson,
           &TypeFieldReflectionOparator::TypeAnimationComponentResOperator::writeByName);
       REGISTER_BASE_CLASS_TO_MAP("AnimationComponentRes", f_class_function_tuple_AnimationComponentRes);
   }
namespace TypeFieldReflectionOparator{
   class TypeAnimationComponentsOperator{
   public:
       static const char* getClassName(){ return "AnimationComponents";}
       static void* constructorWithJson(const PJson& json_context){
          AnimationComponents* ret_instance= new AnimationComponents;
          PSerializer::read(json_context, *ret_instance);
          return ret_instance;
       }
       static PJson writeByName(void* instance){
          return PSerializer::write(*(AnimationComponents*)instance);
       }
       // base class
       static int getAnimationComponentsBaseClassReflectionInstanceList(ReflectionInstance* &out_list, void* instance){
        int count = 0;
        return count;
       }
       // fields
       static const char* getFieldName_schemaFile(){ return "schemaFile";}
       static const char* getFieldTypeName_schemaFile(){ return "std::string";}
       static void set_schemaFile(void* instance, void* field_value){ static_cast<AnimationComponents*>(instance)->schemaFile = *static_cast<std::string*>(field_value);}
       static void* get_schemaFile(void* instance){ return static_cast<void*>(&(static_cast<AnimationComponents*>(instance)->schemaFile));}
       static bool isArray_schemaFile(){ return 0;}
       static const char* getFieldName_components(){ return "components";}
       static const char* getFieldTypeName_components(){ return "std::vector<AnimationComponentRes>";}
       static void set_components(void* instance, void* field_value){ static_cast<AnimationComponents*>(instance)->components = *static_cast<std::vector<AnimationComponentRes>*>(field_value);}
       static void* get_components(void* instance){ return static_cast<void*>(&(static_cast<AnimationComponents*>(instance)->components));}
       static bool isArray_components(){ return 1;}
    };
}//namespace TypeFieldReflectionOparator
namespace ArrayReflectionOperator{
#ifndef ArraystdSSvectorLAnimationComponentResROperatorMACRO
#define ArraystdSSvectorLAnimationComponentResROperatorMACRO
   class ArraystdSSvectorLAnimationComponentResROperator{
   public:
       static const char* getArrayTypeName(){ return "std::vector<AnimationComponentRes>";}
       static const char* getElementTypeName(){ return "AnimationComponentRes";}
       static int getSize(void* instance){
           //todo: should check validation
           return static_cast<int>(static_cast<std::vector<AnimationComponentRes>*>(instance)->size());
       }
       static void* get(int index,void* instance){
           //todo: should check validation
           return static_cast<void*>(&((*static_cast<std::vector<AnimationComponentRes>*>(instance))[index]));
       }
       static void set(int index, void* instance, void* element_value){
           //todo: should check validation
           (*static_cast<std::vector<AnimationComponentRes>*>(instance))[index] = *static_cast<AnimationComponentRes*>(element_value);
       }
   };
#endif //ArraystdSSvectorLAnimationComponentResROperator
}//namespace ArrayReflectionOperator
   void TypeWrapperRegister_AnimationComponents(){
       filed_function_tuple* f_field_function_tuple_schemaFile=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeAnimationComponentsOperator::set_schemaFile,
           &TypeFieldReflectionOparator::TypeAnimationComponentsOperator::get_schemaFile,
           &TypeFieldReflectionOparator::TypeAnimationComponentsOperator::getClassName,
           &TypeFieldReflectionOparator::TypeAnimationComponentsOperator::getFieldName_schemaFile,
           &TypeFieldReflectionOparator::TypeAnimationComponentsOperator::getFieldTypeName_schemaFile,
           &TypeFieldReflectionOparator::TypeAnimationComponentsOperator::isArray_schemaFile);
       REGISTER_FIELD_TO_MAP("AnimationComponents", f_field_function_tuple_schemaFile);
       filed_function_tuple* f_field_function_tuple_components=new filed_function_tuple(
           &TypeFieldReflectionOparator::TypeAnimationComponentsOperator::set_components,
           &TypeFieldReflectionOparator::TypeAnimationComponentsOperator::get_components,
           &TypeFieldReflectionOparator::TypeAnimationComponentsOperator::getClassName,
           &TypeFieldReflectionOparator::TypeAnimationComponentsOperator::getFieldName_components,
           &TypeFieldReflectionOparator::TypeAnimationComponentsOperator::getFieldTypeName_components,
           &TypeFieldReflectionOparator::TypeAnimationComponentsOperator::isArray_components);
       REGISTER_FIELD_TO_MAP("AnimationComponents", f_field_function_tuple_components);
       array_function_tuple* f_array_tuple_stdSSvectorLAnimationComponentResR = new array_function_tuple(
           &ArrayReflectionOperator::ArraystdSSvectorLAnimationComponentResROperator::set,
           &ArrayReflectionOperator::ArraystdSSvectorLAnimationComponentResROperator::get,
           &ArrayReflectionOperator::ArraystdSSvectorLAnimationComponentResROperator::getSize,
           &ArrayReflectionOperator::ArraystdSSvectorLAnimationComponentResROperator::getArrayTypeName,
           &ArrayReflectionOperator::ArraystdSSvectorLAnimationComponentResROperator::getElementTypeName);
       REGISTER_ARRAY_TO_MAP("std::vector<AnimationComponentRes>", f_array_tuple_stdSSvectorLAnimationComponentResR);
       class_function_tuple* f_class_function_tuple_AnimationComponents=new class_function_tuple(
           &TypeFieldReflectionOparator::TypeAnimationComponentsOperator::getAnimationComponentsBaseClassReflectionInstanceList,
           &TypeFieldReflectionOparator::TypeAnimationComponentsOperator::constructorWithJson,
           &TypeFieldReflectionOparator::TypeAnimationComponentsOperator::writeByName);
       REGISTER_BASE_CLASS_TO_MAP("AnimationComponents", f_class_function_tuple_AnimationComponents);
   }
namespace TypeWrappersRegister{
    void AnimationComponentRes(){ TypeWrapperRegister_AnimationComponentRes();}
    void AnimationComponents(){ TypeWrapperRegister_AnimationComponents();}
    void AnimationResult(){ TypeWrapperRegister_AnimationResult();}
    void AnimationResultElement(){ TypeWrapperRegister_AnimationResultElement();}
}//namespace TypeWrappersRegister
}//namespace Reflection
}//namespace Pilot
