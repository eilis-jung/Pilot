#include "runtime/function/ui/ui_system.h"

int Pilot::PUIManager::update() { return 0; }

int Pilot::PUIManager::initialize() { return 0; }

int Pilot::PUIManager::clear() { return 0; }